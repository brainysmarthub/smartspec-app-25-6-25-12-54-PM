import { z } from "zod"

// Login form validation schema
export const loginSchema = z.object({
  email: z.string().min(1, "Email is required").email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required").min(8, "Password must be at least 8 characters long"),
  rememberMe: z.boolean().optional(),
})

// Signup form validation schema
export const signupSchema = z
  .object({
    fullName: z
      .string()
      .min(1, "Full name is required")
      .min(2, "Full name must be at least 2 characters")
      .max(50, "Full name must not exceed 50 characters")
      .regex(/^[a-zA-Z\s]+$/, "Full name can only contain letters and spaces"),
    email: z.string().min(1, "Email is required").email("Please enter a valid email address"),
    password: z
      .string()
      .min(1, "Password is required")
      .min(8, "Password must be at least 8 characters long")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number")
      .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
    confirmPassword: z.string().min(1, "Please confirm your password"),
    company: z.string().max(100, "Company name must not exceed 100 characters").optional(),
    plan: z.enum(["free", "pro", "enterprise"]),
    agreeToTerms: z.boolean().refine((val) => val === true, {
      message: "You must agree to the Terms of Service",
    }),
    agreeToPrivacy: z.boolean().optional(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  })

// Generate form validation schema
export const generateSchema = z.object({
  prompt: z
    .string()
    .min(1, "Please describe your requirements")
    .min(10, "Please provide more detailed requirements (at least 10 characters)")
    .max(2000, "Requirements must not exceed 2000 characters"),
  specType: z.enum(["api", "database", "mobile", "web", "security", "system", "custom"]),
  company: z.string().max(100, "Company name must not exceed 100 characters").optional(),
})

// Type exports for TypeScript
export type LoginFormData = z.infer<typeof loginSchema>
export type SignupFormData = z.infer<typeof signupSchema>
export type GenerateFormData = z.infer<typeof generateSchema>
