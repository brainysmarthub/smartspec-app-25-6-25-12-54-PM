"use client"

import { useState, useEffect } from "react"
import { ErrorBoundary, ComponentErrorFallback } from "@/components/error-boundary"
import { ResourcesSkeleton } from "@/components/loading-skeletons"
import AppLayout from "@/components/app-layout"

export default function ResourcesPage() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading delay
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 800)

    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return (
      <AppLayout>
        <div className="p-6">
          <ResourcesSkeleton />
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      <div className="p-6">
        <ErrorBoundary fallback={ComponentErrorFallback}>
          <h1>Resources</h1>
          <p>This is the resources page.</p>
        </ErrorBoundary>
      </div>
    </AppLayout>
  )
}
