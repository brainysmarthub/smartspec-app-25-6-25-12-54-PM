"use client"

import { useState } from "react"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { User, Camera, Save, CreditCard, Trash2, BarChart3, FileText, Calendar, TrendingUp } from "lucide-react"
import Link from "next/link"

interface UserProfile {
  name: string
  email: string
  company: string
  bio: string
  currentPlan: "free" | "pro" | "enterprise"
  specsGenerated: number
  creditsUsed: number
  creditsRemaining: number
  joinDate: string
}

interface NotificationSettings {
  emailNotifications: boolean
  projectUpdates: boolean
  marketingEmails: boolean
  securityAlerts: boolean
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<UserProfile>({
    name: "John Doe",
    email: "john.doe@example.com",
    company: "Tech Solutions Inc.",
    bio: "Senior Software Engineer with 8+ years of experience in full-stack development.",
    currentPlan: "pro",
    specsGenerated: 47,
    creditsUsed: 1250,
    creditsRemaining: 750,
    joinDate: "January 2024",
  })

  const [notifications, setNotifications] = useState<NotificationSettings>({
    emailNotifications: true,
    projectUpdates: true,
    marketingEmails: false,
    securityAlerts: true,
  })

  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [activeTab, setActiveTab] = useState("account")

  const handleSaveProfile = async () => {
    setIsSaving(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSaving(false)
    setIsEditing(false)
  }

  const getPlanDetails = (plan: string) => {
    switch (plan) {
      case "free":
        return { name: "Free", color: "bg-gray-100 text-gray-800", price: "$0/month" }
      case "pro":
        return { name: "Pro", color: "bg-primary-100 text-primary-800", price: "$29/month" }
      case "enterprise":
        return { name: "Enterprise", color: "bg-secondary-100 text-secondary-800", price: "$99/month" }
      default:
        return { name: "Free", color: "bg-gray-100 text-gray-800", price: "$0/month" }
    }
  }

  const planDetails = getPlanDetails(profile.currentPlan)
  const usagePercentage = (profile.creditsUsed / (profile.creditsUsed + profile.creditsRemaining)) * 100

  return (
    <AppLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-primary-800 mb-2">User Profile</h1>
          <p className="text-gray-600">Manage your account settings and preferences</p>
        </div>

        {/* Profile Header */}
        <Card className="mb-8 border-blue-100">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <div className="relative">
                <div className="w-24 h-24 bg-primary-100 rounded-full flex items-center justify-center">
                  <User className="w-12 h-12 text-primary-700" />
                </div>
                <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-primary-700 rounded-full flex items-center justify-center text-white hover:bg-primary-800">
                  <Camera className="w-4 h-4" />
                </button>
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-primary-800 mb-2">{profile.name}</h1>
                <p className="text-gray-600 mb-2">{profile.email}</p>
                <div className="flex items-center gap-4">
                  <Badge className={planDetails.color}>{planDetails.name} Plan</Badge>
                  <span className="text-sm text-gray-500">Member since {profile.joinDate}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => setIsEditing(!isEditing)}
                  variant="outline"
                  className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                >
                  {isEditing ? "Cancel" : "Edit Profile"}
                </Button>
                {isEditing && (
                  <Button
                    onClick={handleSaveProfile}
                    disabled={isSaving}
                    className="bg-primary-700 hover:bg-primary-800 text-white"
                  >
                    {isSaving ? "Saving..." : "Save Changes"}
                    <Save className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white border border-blue-100">
            <TabsTrigger
              value="account"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Account Info
            </TabsTrigger>
            <TabsTrigger
              value="subscription"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Subscription
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Settings
            </TabsTrigger>
            <TabsTrigger
              value="usage"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Usage Stats
            </TabsTrigger>
          </TabsList>

          {/* Account Information Tab */}
          <TabsContent value="account" className="space-y-6">
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Personal Information</CardTitle>
                <CardDescription>Update your personal details and profile information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={profile.name}
                      onChange={(e) => setProfile((prev) => ({ ...prev, name: e.target.value }))}
                      disabled={!isEditing}
                      className="border-blue-200 focus:border-primary-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profile.email}
                      onChange={(e) => setProfile((prev) => ({ ...prev, email: e.target.value }))}
                      disabled={!isEditing}
                      className="border-blue-200 focus:border-primary-500"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company">Company</Label>
                  <Input
                    id="company"
                    value={profile.company}
                    onChange={(e) => setProfile((prev) => ({ ...prev, company: e.target.value }))}
                    disabled={!isEditing}
                    className="border-blue-200 focus:border-primary-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    value={profile.bio}
                    onChange={(e) => setProfile((prev) => ({ ...prev, bio: e.target.value }))}
                    disabled={!isEditing}
                    className="border-blue-200 focus:border-primary-500 min-h-[100px]"
                    placeholder="Tell us about yourself..."
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Security</CardTitle>
                <CardDescription>Manage your password and security settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="current-password">Current Password</Label>
                  <Input
                    id="current-password"
                    type="password"
                    placeholder="Enter current password"
                    className="border-blue-200 focus:border-primary-500"
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <Input
                      id="new-password"
                      type="password"
                      placeholder="Enter new password"
                      className="border-blue-200 focus:border-primary-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      placeholder="Confirm new password"
                      className="border-blue-200 focus:border-primary-500"
                    />
                  </div>
                </div>
                <Button className="bg-primary-700 hover:bg-primary-800 text-white">Update Password</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Subscription Tab */}
          <TabsContent value="subscription" className="space-y-6">
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Current Plan</CardTitle>
                <CardDescription>Manage your subscription and billing information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg mb-6">
                  <div>
                    <h3 className="text-lg font-semibold text-primary-800">{planDetails.name} Plan</h3>
                    <p className="text-gray-600">{planDetails.price}</p>
                  </div>
                  <Badge className={planDetails.color}>{planDetails.name}</Badge>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-primary-800">Plan Features</h4>
                  <ul className="space-y-2">
                    {profile.currentPlan === "free" && (
                      <>
                        <li className="flex items-center text-sm">
                          <span className="w-2 h-2 bg-primary-600 rounded-full mr-2"></span>5 specifications per month
                        </li>
                        <li className="flex items-center text-sm">
                          <span className="w-2 h-2 bg-primary-600 rounded-full mr-2"></span>Basic templates
                        </li>
                        <li className="flex items-center text-sm">
                          <span className="w-2 h-2 bg-primary-600 rounded-full mr-2"></span>Email support
                        </li>
                      </>
                    )}
                    {profile.currentPlan === "pro" && (
                      <>
                        <li className="flex items-center text-sm">
                          <span className="w-2 h-2 bg-primary-600 rounded-full mr-2"></span>Unlimited specifications
                        </li>
                        <li className="flex items-center text-sm">
                          <span className="w-2 h-2 bg-primary-600 rounded-full mr-2"></span>Premium templates
                        </li>
                        <li className="flex items-center text-sm">
                          <span className="w-2 h-2 bg-primary-600 rounded-full mr-2"></span>Team collaboration
                        </li>
                        <li className="flex items-center text-sm">
                          <span className="w-2 h-2 bg-primary-600 rounded-full mr-2"></span>Priority support
                        </li>
                      </>
                    )}
                  </ul>
                </div>

                <Separator className="my-6" />

                <div className="space-y-4">
                  <h4 className="font-semibold text-primary-800">Usage This Month</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Credits Used</span>
                      <span>
                        {profile.creditsUsed} / {profile.creditsUsed + profile.creditsRemaining}
                      </span>
                    </div>
                    <Progress value={usagePercentage} className="h-2" />
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-primary-700">{profile.specsGenerated}</div>
                      <div className="text-sm text-gray-600">Specs Generated</div>
                    </div>
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-primary-700">{profile.creditsRemaining}</div>
                      <div className="text-sm text-gray-600">Credits Remaining</div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 mt-6">
                  <Link href="/billing">
                    <Button className="bg-primary-700 hover:bg-primary-800 text-white">
                      <CreditCard className="w-4 h-4 mr-2" />
                      Manage Billing
                    </Button>
                  </Link>
                  <Button
                    variant="outline"
                    className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                  >
                    View Billing History
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Notification Preferences</CardTitle>
                <CardDescription>Choose what notifications you want to receive</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Email Notifications</Label>
                    <p className="text-sm text-gray-600">Receive email notifications for important updates</p>
                  </div>
                  <Switch
                    checked={notifications.emailNotifications}
                    onCheckedChange={(checked) =>
                      setNotifications((prev) => ({ ...prev, emailNotifications: checked }))
                    }
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Project Updates</Label>
                    <p className="text-sm text-gray-600">Get notified when your specifications are processed</p>
                  </div>
                  <Switch
                    checked={notifications.projectUpdates}
                    onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, projectUpdates: checked }))}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Marketing Emails</Label>
                    <p className="text-sm text-gray-600">Receive updates about new features and promotions</p>
                  </div>
                  <Switch
                    checked={notifications.marketingEmails}
                    onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, marketingEmails: checked }))}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Security Alerts</Label>
                    <p className="text-sm text-gray-600">Important security notifications (recommended)</p>
                  </div>
                  <Switch
                    checked={notifications.securityAlerts}
                    onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, securityAlerts: checked }))}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-red-200">
              <CardHeader>
                <CardTitle className="text-red-800">Danger Zone</CardTitle>
                <CardDescription>Irreversible and destructive actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 border border-red-200 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-red-800">Delete Account</h4>
                    <p className="text-sm text-gray-600">Permanently delete your account and all associated data</p>
                  </div>
                  <Button variant="destructive" className="bg-red-600 hover:bg-red-700">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete Account
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Usage Statistics Tab */}
          <TabsContent value="usage" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <FileText className="h-8 w-8 text-primary-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Specifications</p>
                      <p className="text-2xl font-bold text-primary-800">{profile.specsGenerated}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <BarChart3 className="h-8 w-8 text-secondary-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Credits Used</p>
                      <p className="text-2xl font-bold text-primary-800">{profile.creditsUsed}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <TrendingUp className="h-8 w-8 text-accent-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">This Month</p>
                      <p className="text-2xl font-bold text-primary-800">12</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Calendar className="h-8 w-8 text-green-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Days Active</p>
                      <p className="text-2xl font-bold text-primary-800">89</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Usage History</CardTitle>
                <CardDescription>Your specification generation activity over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-primary-800">API Documentation Spec</p>
                      <p className="text-sm text-gray-600">Generated on March 15, 2024</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Completed</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-primary-800">Database Schema Specification</p>
                      <p className="text-sm text-gray-600">Generated on March 12, 2024</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Completed</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-primary-800">Mobile App Requirements</p>
                      <p className="text-sm text-gray-600">Generated on March 10, 2024</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Completed</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-primary-800">Security Protocol Spec</p>
                      <p className="text-sm text-gray-600">Generated on March 8, 2024</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Completed</Badge>
                  </div>
                </div>
                <div className="mt-4 text-center">
                  <Button
                    variant="outline"
                    className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                  >
                    View All History
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Monthly Usage Breakdown</CardTitle>
                <CardDescription>Detailed breakdown of your monthly activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-primary-700">8</div>
                    <div className="text-sm text-gray-600">Specs This Week</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-primary-700">32</div>
                    <div className="text-sm text-gray-600">Average Per Month</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-primary-700">95%</div>
                    <div className="text-sm text-gray-600">Success Rate</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  )
}
