"use client"

import { AppLayout } from "@/components/app-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ArrowLeft, Scale, Mail, Calendar, FileText, AlertTriangle } from "lucide-react"

export default function TermsOfServicePage() {
  const lastUpdated = "June 24, 2025"
  const effectiveDate = "June 28, 2025"

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="outline" className="mb-4 bg-white text-primary-700 border-primary-200 hover:bg-primary-50">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
              <Scale className="w-6 h-6 text-primary-700" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-primary-800">Terms of Service</h1>
              <div className="flex items-center gap-4 text-gray-600">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>Last updated: {lastUpdated}</span>
                </div>
                <Badge className="bg-green-100 text-green-800">Effective: {effectiveDate}</Badge>
              </div>
            </div>
          </div>
          <p className="text-lg text-gray-600">
            These Terms of Service govern your use of SmartSpec's AI-powered specification generation platform. Please
            read them carefully before using our services.
          </p>
        </div>

        {/* Important Notice */}
        <Card className="mb-8 border-yellow-200 bg-yellow-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-yellow-800 mb-1">Important Legal Agreement</h3>
                <p className="text-sm text-yellow-700">
                  By accessing or using SmartSpec, you agree to be bound by these Terms of Service. If you do not agree
                  to these terms, please do not use our service.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Table of Contents */}
        <Card className="mb-8 border-blue-100">
          <CardHeader>
            <CardTitle className="text-primary-800 flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Table of Contents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-2">
              <a href="#service-description" className="text-primary-700 hover:underline text-sm">
                1. Service Description
              </a>
              <a href="#acceptable-use" className="text-primary-700 hover:underline text-sm">
                2. Acceptable Use Policy
              </a>
              <a href="#user-accounts" className="text-primary-700 hover:underline text-sm">
                3. User Accounts
              </a>
              <a href="#subscription-billing" className="text-primary-700 hover:underline text-sm">
                4. Subscription & Billing
              </a>
              <a href="#intellectual-property" className="text-primary-700 hover:underline text-sm">
                5. Intellectual Property
              </a>
              <a href="#limitation-liability" className="text-primary-700 hover:underline text-sm">
                6. Limitation of Liability
              </a>
              <a href="#service-availability" className="text-primary-700 hover:underline text-sm">
                7. Service Availability
              </a>
              <a href="#termination" className="text-primary-700 hover:underline text-sm">
                8. Termination
              </a>
              <a href="#governing-law" className="text-primary-700 hover:underline text-sm">
                9. Governing Law
              </a>
              <a href="#contact-legal" className="text-primary-700 hover:underline text-sm">
                10. Legal Contact
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="space-y-8">
          {/* Section 1: Service Description */}
          <Card id="service-description" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">1. Service Description</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                SmartSpec is an AI-powered platform that helps users generate comprehensive technical specifications,
                documentation, and project requirements. Our service includes:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Core Features</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>AI-powered specification generation</li>
                    <li>Document upload and analysis</li>
                    <li>Template library and customization</li>
                    <li>Export and sharing capabilities</li>
                  </ul>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Collaboration Tools</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Team workspace management</li>
                    <li>Real-time collaboration features</li>
                    <li>Version control and history</li>
                    <li>Comment and review systems</li>
                  </ul>
                </div>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>Service Evolution:</strong> We continuously improve our service by adding new features,
                  updating AI models, and enhancing user experience. Some features may be in beta or experimental
                  phases.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 2: Acceptable Use Policy */}
          <Card id="acceptable-use" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">2. Acceptable Use Policy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                You agree to use SmartSpec responsibly and in compliance with all applicable laws. The following
                activities are prohibited:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-red-800 mb-2">Prohibited Content</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Illegal, harmful, or offensive content</li>
                    <li>Copyrighted material without permission</li>
                    <li>Personal information of others</li>
                    <li>Malicious code or security threats</li>
                  </ul>
                </div>
                <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-red-800 mb-2">Prohibited Activities</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Attempting to breach security measures</li>
                    <li>Reverse engineering our AI models</li>
                    <li>Automated scraping or data mining</li>
                    <li>Reselling or redistributing our service</li>
                  </ul>
                </div>
              </div>
              <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Encouraged Use</h4>
                <p className="text-sm text-gray-700">
                  We encourage creative and productive use of SmartSpec for legitimate business purposes, educational
                  projects, and professional development. Help us build a positive community by reporting any misuse.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 3: User Accounts */}
          <Card id="user-accounts" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">3. User Accounts and Responsibilities</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-primary-700 mb-2">Account Creation</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Provide accurate and complete information</li>
                    <li>Use a valid email address you control</li>
                    <li>Choose a secure password</li>
                    <li>You must be at least 18 years old</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-primary-700 mb-2">Account Security</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Keep your login credentials confidential</li>
                    <li>Enable two-factor authentication</li>
                    <li>Report suspicious activity immediately</li>
                    <li>Log out from shared or public devices</li>
                  </ul>
                </div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-primary-700 mb-2">Account Responsibility</h4>
                <p className="text-sm text-gray-700">
                  You are responsible for all activities that occur under your account. This includes actions by team
                  members you invite to your workspace. Ensure all users understand and comply with these terms.
                </p>
              </div>
              <div className="bg-orange-50 border border-orange-200 p-4 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">Business Accounts</h4>
                <p className="text-sm text-gray-700">
                  If you're creating an account on behalf of a company or organization, you represent that you have the
                  authority to bind that entity to these terms.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 4: Subscription and Billing */}
          <Card id="subscription-billing" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">4. Subscription Terms and Billing</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Free Plan</h4>
                  <ul className="list-disc list-inside space-y-1 text-xs text-gray-700">
                    <li>5 specifications per month</li>
                    <li>Basic templates</li>
                    <li>Email support</li>
                    <li>No credit card required</li>
                  </ul>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Pro Plan ($29/month)</h4>
                  <ul className="list-disc list-inside space-y-1 text-xs text-gray-700">
                    <li>Unlimited specifications</li>
                    <li>Premium templates</li>
                    <li>Team collaboration</li>
                    <li>Priority support</li>
                  </ul>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Enterprise ($99/month)</h4>
                  <ul className="list-disc list-inside space-y-1 text-xs text-gray-700">
                    <li>Everything in Pro</li>
                    <li>Advanced security</li>
                    <li>Custom integrations</li>
                    <li>Dedicated support</li>
                  </ul>
                </div>
              </div>
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">Billing Terms</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Subscriptions are billed monthly or annually in advance</li>
                    <li>All fees are non-refundable except as required by law</li>
                    <li>Prices may change with 30 days notice</li>
                    <li>Failed payments may result in service suspension</li>
                  </ul>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Cancellation Policy</h4>
                  <p className="text-sm text-gray-700">
                    You may cancel your subscription at any time. Cancellation takes effect at the end of your current
                    billing period. You'll retain access to paid features until then. Downgrading may result in loss of
                    data that exceeds free plan limits.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 5: Intellectual Property */}
          <Card id="intellectual-property" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">5. Intellectual Property Rights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">Your Content Rights</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>You retain ownership of all content you upload</li>
                    <li>Generated specifications belong to you</li>
                    <li>We don't claim rights to your intellectual property</li>
                    <li>You can export and use your content freely</li>
                  </ul>
                </div>
                <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">SmartSpec Rights</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>We own the SmartSpec platform and technology</li>
                    <li>Our AI models and algorithms are proprietary</li>
                    <li>Templates and examples are our intellectual property</li>
                    <li>Trademarks and branding belong to SmartSpec</li>
                  </ul>
                </div>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-2">License Grant</h4>
                <p className="text-sm text-gray-700">
                  You grant us a limited license to process your content solely to provide our services. This includes
                  storing, analyzing, and generating specifications based on your inputs. We do not use your content to
                  train our AI models or share it with third parties.
                </p>
              </div>
              <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                <h4 className="font-semibold text-red-800 mb-2">Copyright Infringement</h4>
                <p className="text-sm text-gray-700">
                  If you believe your copyrighted work has been infringed, please contact us at{" "}
                  <a href="mailto:legal@smartspec.ai" className="text-primary-700 hover:underline">
                    info@spxid.ai
                  </a>{" "}
                  with details. We will investigate and take appropriate action in accordance with the DMCA.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 6: Limitation of Liability */}
          <Card id="limitation-liability" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">6. Limitation of Liability and Disclaimers</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                <h4 className="font-semibold text-red-800 mb-2">Service Disclaimer</h4>
                <p className="text-sm text-gray-700">
                  SmartSpec is provided "as is" without warranties of any kind. While we strive for accuracy,
                  AI-generated content may contain errors or inaccuracies. You are responsible for reviewing and
                  validating all generated specifications before use.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-orange-50 border border-orange-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-orange-800 mb-2">Liability Limitations</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>No liability for indirect or consequential damages</li>
                    <li>Total liability limited to fees paid in the last 12 months</li>
                    <li>No liability for third-party content or services</li>
                    <li>Force majeure events are excluded</li>
                  </ul>
                </div>
                <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-yellow-800 mb-2">User Responsibilities</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Verify accuracy of generated content</li>
                    <li>Ensure compliance with applicable laws</li>
                    <li>Maintain appropriate backups</li>
                    <li>Use professional judgment in implementation</li>
                  </ul>
                </div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-primary-700 mb-2">Professional Advice Disclaimer</h4>
                <p className="text-sm text-gray-700">
                  SmartSpec does not provide legal, financial, or professional advice. Generated specifications are for
                  informational purposes only and should not replace consultation with qualified professionals for
                  critical projects.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 7: Service Availability */}
          <Card id="service-availability" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">7. Service Availability and Modifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">Service Commitment</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>99.9% uptime target for paid plans</li>
                    <li>Scheduled maintenance with advance notice</li>
                    <li>Redundant systems and backups</li>
                    <li>24/7 monitoring and support</li>
                  </ul>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">Service Changes</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>We may modify features with notice</li>
                    <li>New features may be added regularly</li>
                    <li>Beta features may be discontinued</li>
                    <li>API changes will be versioned</li>
                  </ul>
                </div>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-2">Service Interruptions</h4>
                <p className="text-sm text-gray-700">
                  While we strive for continuous availability, service interruptions may occur due to maintenance,
                  updates, or unforeseen circumstances. We will provide status updates and work to restore service
                  quickly.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 8: Termination */}
          <Card id="termination" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">8. Termination Conditions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">Termination by You</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Cancel subscription anytime</li>
                    <li>Delete account through settings</li>
                    <li>Export your data before deletion</li>
                    <li>No penalties for cancellation</li>
                  </ul>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-red-800 mb-2">Termination by SmartSpec</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Violation of terms of service</li>
                    <li>Non-payment of fees</li>
                    <li>Fraudulent or illegal activity</li>
                    <li>Abuse of service or resources</li>
                  </ul>
                </div>
              </div>
              <div className="bg-orange-50 border border-orange-200 p-4 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">Data Retention After Termination</h4>
                <p className="text-sm text-gray-700">
                  After account termination, we will retain your data for 30 days to allow for reactivation. After this
                  period, all data will be permanently deleted. You can request immediate deletion by contacting
                  support.
                </p>
              </div>
              <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Survival of Terms</h4>
                <p className="text-sm text-gray-700">
                  Certain provisions of these terms will survive termination, including intellectual property rights,
                  limitation of liability, and dispute resolution procedures.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 9: Governing Law */}
          <Card id="governing-law" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">9. Governing Law and Dispute Resolution</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">Governing Law</h4>
                  <p className="text-sm text-gray-700">
                    These terms are governed by the laws of the State of Kuwait, without regard to conflict of law
                    principles. Any disputes will be resolved in the courts of Kuwait.
                  </p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">Dispute Resolution</h4>
                  <p className="text-sm text-gray-700">
                    We encourage resolving disputes through direct communication. For formal disputes, we prefer
                    mediation before litigation. Class action lawsuits are waived except where prohibited by law.
                  </p>
                </div>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-2">International Users</h4>
                <p className="text-sm text-gray-700">
                  If you are accessing SmartSpec from outside State of Kuwait, you acknowledge that your information
                  will be transferred to and processed in State of Kuwait, and you consent to such transfer and
                  processing.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 10: Legal Contact */}
          <Card id="contact-legal" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800 flex items-center">
                <Mail className="w-5 h-5 mr-2" />
                10. Legal Contact Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                For legal matters, contract questions, or terms-related inquiries, please contact us:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Legal Department</h4>
                  <div className="space-y-1 text-sm text-gray-700">
                    <p>Email: info@spxid.ai</p>
                    <p>Response Time: Within 5 business days</p>
                    <p>For urgent matters: Mark subject as "URGENT"</p>
                  </div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Business Address</h4>
                  <div className="space-y-1 text-sm text-gray-700">
                    <p>SPXID Legal Team</p>
                    <p>P.O. Box 4997</p>
                    <p>Safat Kuwait 13038</p>
                  </div>
                </div>
              </div>
              <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Enterprise Customers</h4>
                <p className="text-sm text-gray-700">
                  Enterprise customers with custom agreements should contact their dedicated account manager or email
                  enterprise@smartspec.ai for contract-related matters.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Updates and Changes */}
          <Card className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">Terms Updates and Changes</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4">
                We may update these Terms of Service to reflect changes in our service, legal requirements, or business
                practices. When we make material changes:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4">
                <li>We will notify you via email at least 30 days before changes take effect</li>
                <li>We will post a notice on our website and in your account dashboard</li>
                <li>We will update the "Last Updated" date at the top of these terms</li>
                <li>Continued use of the service constitutes acceptance of new terms</li>
              </ul>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>Current Version:</strong> These Terms of Service were last updated on June 24, 2025 and become
                  effective on June 28, 2025.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer Navigation */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex gap-4">
              <Link href="/privacy-policy">
                <Button variant="outline" className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50">
                  Privacy Policy
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50">
                  Contact Legal Team
                </Button>
              </Link>
            </div>
            <Link href="/">
              <Button className="bg-primary-700 hover:bg-primary-800 text-white">Return to SmartSpec</Button>
            </Link>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
