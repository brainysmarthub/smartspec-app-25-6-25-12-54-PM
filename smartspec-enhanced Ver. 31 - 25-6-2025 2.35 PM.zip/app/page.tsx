"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, FileText, Zap, Shield, Users, ArrowRight } from "lucide-react"

export default function LandingPage() {
  const [isPricingHighlighted, setIsPricingHighlighted] = useState(false)
  const searchParams = useSearchParams()

  useEffect(() => {
    // Check if we should scroll to pricing section
    const scrollToPricing = searchParams.get("scrollTo")

    if (scrollToPricing === "pricing") {
      // Small delay to ensure page is fully loaded
      setTimeout(() => {
        const pricingSection = document.getElementById("pricing-section")
        if (pricingSection) {
          pricingSection.scrollIntoView({
            behavior: "smooth",
            block: "start",
          })

          // Add highlight effect
          setIsPricingHighlighted(true)

          // Remove highlight after animation
          setTimeout(() => {
            setIsPricingHighlighted(false)
          }, 3000)
        }
      }, 100)
    }
  }, [searchParams])

  return (
    <AppLayout>
      <div className="min-h-screen">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-24 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-primary-100 text-primary-800 hover:bg-primary-200">
              AI-Powered Specification Generation
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Generate Perfect
              <span className="text-primary-700 block">Technical Specifications</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Transform your ideas into comprehensive technical specifications with AI. Save time, reduce errors, and
              ensure consistency across all your projects.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/signup">
                <Button size="lg" className="bg-primary-700 hover:bg-primary-800 text-white px-8 py-3 text-lg">
                  Start Free
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/generate">
                <Button
                  variant="outline"
                  size="lg"
                  className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50 px-8 py-3 text-lg"
                >
                  Try Generator
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-24 bg-white/50 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Powerful Features for Modern Development
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Everything you need to create, manage, and maintain technical specifications efficiently.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="border-blue-100 hover:border-primary-200 transition-colors">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                    <Zap className="h-6 w-6 text-primary-700" />
                  </div>
                  <CardTitle className="text-primary-800">AI-Powered Generation</CardTitle>
                  <CardDescription>
                    Generate comprehensive specifications from simple descriptions using advanced AI technology.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-blue-100 hover:border-primary-200 transition-colors">
                <CardHeader>
                  <div className="w-12 h-12 bg-secondary-100 rounded-lg flex items-center justify-center mb-4">
                    <FileText className="h-6 w-6 text-secondary-700" />
                  </div>
                  <CardTitle className="text-primary-800">Template Library</CardTitle>
                  <CardDescription>
                    Access hundreds of pre-built templates for different industries and project types.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-blue-100 hover:border-primary-200 transition-colors">
                <CardHeader>
                  <div className="w-12 h-12 bg-accent-100 rounded-lg flex items-center justify-center mb-4">
                    <Users className="h-6 w-6 text-accent-700" />
                  </div>
                  <CardTitle className="text-primary-800">Team Collaboration</CardTitle>
                  <CardDescription>
                    Work together with your team in real-time with comments, reviews, and version control.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-blue-100 hover:border-primary-200 transition-colors">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                    <Shield className="h-6 w-6 text-primary-700" />
                  </div>
                  <CardTitle className="text-primary-800">Enterprise Security</CardTitle>
                  <CardDescription>
                    Bank-level security with encryption, compliance, and audit trails for enterprise needs.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-blue-100 hover:border-primary-200 transition-colors">
                <CardHeader>
                  <div className="w-12 h-12 bg-secondary-100 rounded-lg flex items-center justify-center mb-4">
                    <CheckCircle className="h-6 w-6 text-secondary-700" />
                  </div>
                  <CardTitle className="text-primary-800">Quality Assurance</CardTitle>
                  <CardDescription>
                    Automated quality checks and validation to ensure your specifications meet industry standards.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-blue-100 hover:border-primary-200 transition-colors">
                <CardHeader>
                  <div className="w-12 h-12 bg-accent-100 rounded-lg flex items-center justify-center mb-4">
                    <ArrowRight className="h-6 w-6 text-accent-700" />
                  </div>
                  <CardTitle className="text-primary-800">Export & Integration</CardTitle>
                  <CardDescription>
                    Export to multiple formats and integrate with your existing tools and workflows.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section
          id="pricing-section"
          className={`py-24 bg-blue-50/50 px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
            isPricingHighlighted ? "ring-4 ring-primary-200 ring-opacity-50 bg-primary-50/30" : ""
          }`}
        >
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h2>
              <p className="text-xl text-gray-600">
                Choose the plan that fits your needs. Upgrade or downgrade at any time.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <Card className="border-blue-200">
                <CardHeader>
                  <CardTitle className="text-primary-800">Free</CardTitle>
                  <div className="text-3xl font-bold text-primary-700">
                    $0<span className="text-lg font-normal text-gray-600">/month</span>
                  </div>
                  <CardDescription>Perfect for getting started</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />5 specifications per month
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Basic templates
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Email support
                    </li>
                  </ul>
                  <Link href="/signup">
                    <Button className="w-full bg-primary-700 hover:bg-primary-800 text-white">Get Started</Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-primary-300 ring-2 ring-primary-200">
                <CardHeader>
                  <Badge className="w-fit mb-2 bg-primary-100 text-primary-800">Most Popular</Badge>
                  <CardTitle className="text-primary-800">Pro</CardTitle>
                  <div className="text-3xl font-bold text-primary-700">
                    $29<span className="text-lg font-normal text-gray-600">/month</span>
                  </div>
                  <CardDescription>For growing teams and projects</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Unlimited specifications
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Premium templates
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Team collaboration
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Priority support
                    </li>
                  </ul>
                  <Link href="/signup">
                    <Button className="w-full bg-primary-700 hover:bg-primary-800 text-white">Start Pro Trial</Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-blue-200">
                <CardHeader>
                  <CardTitle className="text-primary-800">Enterprise</CardTitle>
                  <div className="text-3xl font-bold text-primary-700">
                    $99<span className="text-lg font-normal text-gray-600">/month</span>
                  </div>
                  <CardDescription>For large organizations</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Everything in Pro
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Advanced security
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Custom integrations
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-2" />
                      Dedicated support
                    </li>
                  </ul>
                  <Link href="/signup">
                    <Button className="w-full bg-primary-700 hover:bg-primary-800 text-white">Contact Sales</Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-primary-700 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ready to Transform Your Workflow?</h2>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Join thousands of developers and teams who are already using SmartSpec to create better specifications
              faster.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/signup">
                <Button size="lg" className="bg-white text-primary-700 hover:bg-blue-50 px-8 py-3 text-lg">
                  Start Your Free Trial
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/generate">
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white text-white hover:bg-white/10 px-8 py-3 text-lg"
                >
                  Try Generator Now
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-4 gap-8">
              <div>
                <h3 className="text-2xl font-bold mb-4">SmartSpec</h3>
                <p className="text-gray-400 mb-4">
                  AI-powered technical specification generation for modern development teams.
                </p>
                <div className="flex space-x-4">
                  <Link href="/privacy-policy" className="text-gray-400 hover:text-white transition-colors text-sm">
                    Privacy Policy
                  </Link>
                  <Link href="/terms-of-service" className="text-gray-400 hover:text-white transition-colors text-sm">
                    Terms of Service
                  </Link>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Product</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <Link href="/generate" className="hover:text-white transition-colors">
                      Generator
                    </Link>
                  </li>
                  <li>
                    <Link href="/dashboard" className="hover:text-white transition-colors">
                      Dashboard
                    </Link>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Templates
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Company</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      About
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Blog
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Careers
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Support</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <Link href="/help" className="hover:text-white transition-colors">
                      Help Center
                    </Link>
                  </li>
                  <li>
                    <a href="mailto:support@smartspec.ai" className="hover:text-white transition-colors">
                      Contact
                    </a>
                  </li>
                  <li>
                    <Link href="/privacy-policy" className="hover:text-white transition-colors">
                      Privacy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col sm:flex-row justify-between items-center">
              <p className="text-gray-400 text-sm">&copy; 2024 SmartSpec. All rights reserved.</p>
              <div className="flex space-x-4 mt-4 sm:mt-0">
                <Link href="/terms-of-service" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Terms
                </Link>
                <Link href="/privacy-policy" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Privacy
                </Link>
                <a
                  href="mailto:legal@smartspec.ai"
                  className="text-gray-400 hover:text-white transition-colors text-sm"
                >
                  Legal
                </a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </AppLayout>
  )
}
