"use client"

import { AppLayout } from "@/components/app-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ArrowLeft, Shield, Mail, Calendar, FileText } from "lucide-react"

export default function PrivacyPolicyPage() {
  const lastUpdated = "December 24, 2024"

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="outline" className="mb-4 bg-white text-primary-700 border-primary-200 hover:bg-primary-50">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-primary-700" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-primary-800">Privacy Policy</h1>
              <div className="flex items-center gap-2 text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>Last updated: {lastUpdated}</span>
              </div>
            </div>
          </div>
          <p className="text-lg text-gray-600">
            SmartSpec is committed to protecting your privacy and ensuring the security of your personal information.
            This Privacy Policy explains how we collect, use, and safeguard your data.
          </p>
        </div>

        {/* Table of Contents */}
        <Card className="mb-8 border-blue-100">
          <CardHeader>
            <CardTitle className="text-primary-800 flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Table of Contents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-2">
              <a href="#information-collection" className="text-primary-700 hover:underline text-sm">
                1. Information We Collect
              </a>
              <a href="#data-usage" className="text-primary-700 hover:underline text-sm">
                2. How We Use Your Data
              </a>
              <a href="#document-handling" className="text-primary-700 hover:underline text-sm">
                3. Document Handling
              </a>
              <a href="#cookies" className="text-primary-700 hover:underline text-sm">
                4. Cookies and Tracking
              </a>
              <a href="#third-party" className="text-primary-700 hover:underline text-sm">
                5. Third-Party Services
              </a>
              <a href="#data-security" className="text-primary-700 hover:underline text-sm">
                6. Data Security
              </a>
              <a href="#user-rights" className="text-primary-700 hover:underline text-sm">
                7. Your Rights
              </a>
              <a href="#compliance" className="text-primary-700 hover:underline text-sm">
                8. Legal Compliance
              </a>
              <a href="#contact" className="text-primary-700 hover:underline text-sm">
                9. Contact Information
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="space-y-8">
          {/* Section 1: Information We Collect */}
          <Card id="information-collection" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">1. Information We Collect</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-primary-700 mb-2">Personal Information</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Name and email address (required for account creation)</li>
                  <li>Company name and job title (optional)</li>
                  <li>Profile information and bio (optional)</li>
                  <li>Payment information (processed securely through third-party providers)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-primary-700 mb-2">Usage Data</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Specifications generated and their metadata</li>
                  <li>Feature usage patterns and preferences</li>
                  <li>Login times and session duration</li>
                  <li>Device information and browser type</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-primary-700 mb-2">Technical Data</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>IP address and location data</li>
                  <li>Log files and error reports</li>
                  <li>Performance metrics and analytics</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Section 2: How We Use Your Data */}
          <Card id="data-usage" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">2. How We Use Your Data</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">We use your information for the following purposes:</p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Service Provision</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Generate AI-powered specifications</li>
                    <li>Manage your account and preferences</li>
                    <li>Process payments and subscriptions</li>
                    <li>Provide customer support</li>
                  </ul>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Service Improvement</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Analyze usage patterns</li>
                    <li>Improve AI model performance</li>
                    <li>Develop new features</li>
                    <li>Ensure service security</li>
                  </ul>
                </div>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>Important:</strong> We never use your uploaded documents or generated specifications to train
                  our AI models or share them with third parties without your explicit consent.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 3: Document Handling */}
          <Card id="document-handling" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">3. Document Handling & Processing</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Your Documents Are Secure</h4>
                <p className="text-sm text-gray-700">
                  All uploaded documents and generated specifications are encrypted and stored securely. We implement
                  industry-standard security measures to protect your intellectual property.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-primary-700 mb-2">Document Processing</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Documents are processed in secure, isolated environments</li>
                  <li>Temporary processing files are automatically deleted after use</li>
                  <li>Access is restricted to authorized personnel only</li>
                  <li>All processing activities are logged and monitored</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-primary-700 mb-2">Data Retention</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Your documents are stored only as long as necessary for service provision</li>
                  <li>You can delete your documents at any time from your account</li>
                  <li>Deleted documents are permanently removed within 30 days</li>
                  <li>Backup copies are securely destroyed according to our retention schedule</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Section 4: Cookies and Tracking */}
          <Card id="cookies" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">4. Cookies and Tracking Technologies</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                We use cookies and similar technologies to enhance your experience and analyze service usage.
              </p>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Essential Cookies</h4>
                  <p className="text-sm text-gray-700">
                    Required for basic site functionality, authentication, and security.
                  </p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Analytics Cookies</h4>
                  <p className="text-sm text-gray-700">
                    Help us understand how you use our service to improve performance.
                  </p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Preference Cookies</h4>
                  <p className="text-sm text-gray-700">
                    Remember your settings and preferences for a better experience.
                  </p>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                You can control cookie preferences through your browser settings. Note that disabling essential cookies
                may affect service functionality.
              </p>
            </CardContent>
          </Card>

          {/* Section 5: Third-Party Services */}
          <Card id="third-party" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">5. Third-Party Integrations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                We work with trusted third-party services to provide our functionality. All partners are carefully
                vetted for security and privacy compliance.
              </p>
              <div className="space-y-4">
                <div className="border border-gray-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">AI Processing</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Google Cloud AI Platform for specification generation</li>
                    <li>OpenAI API for advanced language processing</li>
                    <li>All data is encrypted in transit and at rest</li>
                  </ul>
                </div>
                <div className="border border-gray-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Payment Processing</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Stripe for secure payment processing</li>
                    <li>We never store your payment card information</li>
                    <li>All transactions are PCI DSS compliant</li>
                  </ul>
                </div>
                <div className="border border-gray-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Analytics & Monitoring</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Google Analytics for usage insights</li>
                    <li>Sentry for error monitoring and debugging</li>
                    <li>Data is anonymized where possible</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 6: Data Security */}
          <Card id="data-security" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">6. Data Security Measures</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <h4 className="font-semibold text-primary-700 mb-2">Enterprise-Grade Security</h4>
                <p className="text-sm text-gray-700">
                  We implement multiple layers of security to protect your data, including encryption, access controls,
                  and regular security audits.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-primary-700 mb-2">Technical Safeguards</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>AES-256 encryption for data at rest</li>
                    <li>TLS 1.3 encryption for data in transit</li>
                    <li>Regular security vulnerability assessments</li>
                    <li>Automated backup and disaster recovery</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-primary-700 mb-2">Access Controls</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    <li>Multi-factor authentication for all accounts</li>
                    <li>Role-based access control for team members</li>
                    <li>Regular access reviews and audits</li>
                    <li>Secure API authentication and authorization</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 7: Your Rights */}
          <Card id="user-rights" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">7. Your Privacy Rights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                You have several rights regarding your personal data. We are committed to honoring these rights and
                making them easy to exercise.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="bg-green-50 p-3 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-1">Access & Portability</h4>
                    <p className="text-sm text-gray-700">Request a copy of your personal data in a portable format.</p>
                  </div>
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-1">Correction</h4>
                    <p className="text-sm text-gray-700">Update or correct inaccurate personal information.</p>
                  </div>
                  <div className="bg-yellow-50 p-3 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-1">Deletion</h4>
                    <p className="text-sm text-gray-700">Request deletion of your personal data and account.</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="bg-purple-50 p-3 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-1">Processing Restriction</h4>
                    <p className="text-sm text-gray-700">Limit how we process your personal data.</p>
                  </div>
                  <div className="bg-orange-50 p-3 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-1">Objection</h4>
                    <p className="text-sm text-gray-700">Object to certain types of data processing.</p>
                  </div>
                  <div className="bg-red-50 p-3 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-1">Withdraw Consent</h4>
                    <p className="text-sm text-gray-700">Withdraw consent for data processing at any time.</p>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>How to Exercise Your Rights:</strong> Contact us at{" "}
                  <a href="mailto:privacy@smartspec.ai" className="text-primary-700 hover:underline">
                    privacy@smartspec.ai
                  </a>{" "}
                  or use the privacy controls in your account settings. We will respond to your request within 30 days.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 8: Legal Compliance */}
          <Card id="compliance" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">8. Legal Compliance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-blue-600 text-white">GDPR</Badge>
                    <h4 className="font-semibold text-primary-700">European Union</h4>
                  </div>
                  <p className="text-sm text-gray-700">
                    We comply with the General Data Protection Regulation (GDPR) for all EU residents. This includes
                    lawful basis for processing, data minimization, and enhanced user rights.
                  </p>
                </div>
                <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-green-600 text-white">CCPA</Badge>
                    <h4 className="font-semibold text-primary-700">California</h4>
                  </div>
                  <p className="text-sm text-gray-700">
                    We comply with the California Consumer Privacy Act (CCPA) for California residents, including rights
                    to know, delete, and opt-out of the sale of personal information.
                  </p>
                </div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold text-primary-700 mb-2">International Data Transfers</h4>
                <p className="text-sm text-gray-700">
                  When we transfer personal data internationally, we use appropriate safeguards such as Standard
                  Contractual Clauses (SCCs) and ensure adequate protection levels. Our primary data processing occurs
                  within the United States and European Union.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 9: Contact Information */}
          <Card id="contact" className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800 flex items-center">
                <Mail className="w-5 h-5 mr-2" />
                9. Contact Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                If you have any questions about this Privacy Policy or our data practices, please contact us:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Privacy Officer</h4>
                  <div className="space-y-1 text-sm text-gray-700">
                    <p>Email: info@spxid.ai</p>
                    <p>Response Time: Within 48 hours</p>
                  </div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-primary-700 mb-2">Mailing Address</h4>
                  <div className="space-y-1 text-sm text-gray-700">
                    <p>SPX ID Privacy Team</p>
                    <p>P.O. Box XXXX</p>
                    <p>Safat Kuwait 13038</p>
                  </div>
                </div>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>Data Protection Officer (EU):</strong> For EU-related privacy matters, contact our Data
                  Protection Officer at dpo@smartspec.ai
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Updates Section */}
          <Card className="border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">Policy Updates</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4">
                We may update this Privacy Policy from time to time to reflect changes in our practices or legal
                requirements. When we make significant changes, we will:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4">
                <li>Notify you via email at least 30 days before changes take effect</li>
                <li>Display a prominent notice on our website</li>
                <li>Update the "Last Updated" date at the top of this policy</li>
                <li>Provide a summary of key changes</li>
              </ul>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>Current Version:</strong> This Privacy Policy was last updated on {lastUpdated} and is
                  effective immediately.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer Navigation */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex gap-4">
              <Link href="/terms-of-service">
                <Button variant="outline" className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50">
                  Terms of Service
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50">
                  Contact Support
                </Button>
              </Link>
            </div>
            <Link href="/">
              <Button className="bg-primary-700 hover:bg-primary-800 text-white">Return to SmartSpec</Button>
            </Link>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
