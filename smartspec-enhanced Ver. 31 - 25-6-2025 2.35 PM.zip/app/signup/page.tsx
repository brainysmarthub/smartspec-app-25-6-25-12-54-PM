"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import Link from "next/link"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Eye, EyeOff, Loader2, AlertCircle, Check } from "lucide-react"
import { signupSchema, type SignupFormData } from "@/lib/validation-schemas"

export default function SignupPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors, isValid, touchedFields },
    setValue,
    watch,
    trigger,
  } = useForm<SignupFormData>({
    resolver: zodResolver(signupSchema),
    mode: "onChange",
    defaultValues: {
      fullName: "",
      email: "",
      password: "",
      confirmPassword: "",
      company: "",
      plan: "free",
      agreeToTerms: false,
      agreeToPrivacy: false,
    },
  })

  const watchedPassword = watch("password")
  const watchedPlan = watch("plan")
  const watchedAgreeToTerms = watch("agreeToTerms")
  const watchedAgreeToPrivacy = watch("agreeToPrivacy")

  const getPasswordStrength = (password: string) => {
    let strength = 0
    if (password.length >= 8) strength++
    if (/[A-Z]/.test(password)) strength++
    if (/[a-z]/.test(password)) strength++
    if (/[0-9]/.test(password)) strength++
    if (/[^A-Za-z0-9]/.test(password)) strength++
    return strength
  }

  const getPasswordStrengthText = (strength: number) => {
    switch (strength) {
      case 0:
      case 1:
        return { text: "Very Weak", color: "text-red-600", bgColor: "bg-red-500" }
      case 2:
        return { text: "Weak", color: "text-orange-600", bgColor: "bg-orange-500" }
      case 3:
        return { text: "Fair", color: "text-yellow-600", bgColor: "bg-yellow-500" }
      case 4:
        return { text: "Good", color: "text-blue-600", bgColor: "bg-blue-500" }
      case 5:
        return { text: "Strong", color: "text-green-600", bgColor: "bg-green-500" }
      default:
        return { text: "", color: "", bgColor: "" }
    }
  }

  const getInputClassName = (fieldName: keyof SignupFormData) => {
    const baseClass = "border-blue-200 focus:border-primary-500 transition-colors"
    const errorClass = "border-red-500 focus:border-red-500"
    const successClass = "border-green-500 focus:border-green-500"

    if (errors[fieldName]) return errorClass
    if (touchedFields[fieldName] && !errors[fieldName]) return successClass
    return baseClass
  }

  const onSubmit = async (data: SignupFormData) => {
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))
      setIsSuccess(true)
    } catch (error) {
      console.error("Signup failed:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (isSuccess) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-screen p-4">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-2xl text-primary-800">Welcome to SmartSpec!</CardTitle>
              <CardDescription>
                Your account has been created successfully. Please check your email to verify your account.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold text-primary-800 mb-2">What's Next?</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Check your email for verification link</li>
                  <li>• Complete your profile setup</li>
                  <li>• Start creating your first specification</li>
                </ul>
              </div>
              <div className="flex flex-col gap-2">
                <Link href="/dashboard">
                  <Button className="w-full bg-primary-700 hover:bg-primary-800 text-white">Go to Dashboard</Button>
                </Link>
                <Link href="/">
                  <Button
                    variant="outline"
                    className="w-full bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                  >
                    Back to Home
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    )
  }

  const passwordStrength = getPasswordStrength(watchedPassword || "")
  const passwordStrengthInfo = getPasswordStrengthText(passwordStrength)

  return (
    <AppLayout>
      <div className="flex items-center justify-center min-h-screen p-4">
        <Card className="w-full max-w-2xl">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-primary-800">Create Your Account</CardTitle>
            <CardDescription className="text-center">
              Join thousands of developers using SmartSpec to create better specifications
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Personal Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary-800">Personal Information</h3>

                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name *</Label>
                  <Input
                    id="fullName"
                    type="text"
                    {...register("fullName")}
                    className={getInputClassName("fullName")}
                    placeholder="Enter your full name"
                    autoComplete="name"
                  />
                  {errors.fullName && (
                    <div className="flex items-center space-x-1 text-sm text-red-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.fullName.message}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    {...register("email")}
                    className={getInputClassName("email")}
                    placeholder="Enter your email address"
                    autoComplete="email"
                  />
                  {errors.email && (
                    <div className="flex items-center space-x-1 text-sm text-red-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.email.message}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="company">Company Name (Optional)</Label>
                  <Input
                    id="company"
                    type="text"
                    {...register("company")}
                    className={getInputClassName("company")}
                    placeholder="Enter your company name"
                    autoComplete="organization"
                  />
                  {errors.company && (
                    <div className="flex items-center space-x-1 text-sm text-red-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.company.message}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Password Section */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary-800">Security</h3>

                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      {...register("password", {
                        onChange: () => trigger("confirmPassword"),
                      })}
                      className={`${getInputClassName("password")} pr-10`}
                      placeholder="Create a strong password"
                      autoComplete="new-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {watchedPassword && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full transition-all ${passwordStrengthInfo.bgColor}`}
                            style={{ width: `${(passwordStrength / 5) * 100}%` }}
                          />
                        </div>
                        <span className={`text-sm font-medium ${passwordStrengthInfo.color}`}>
                          {passwordStrengthInfo.text}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div
                          className={`flex items-center space-x-1 ${/[A-Z]/.test(watchedPassword) ? "text-green-600" : "text-gray-400"}`}
                        >
                          <Check className="w-3 h-3" />
                          <span>Uppercase letter</span>
                        </div>
                        <div
                          className={`flex items-center space-x-1 ${/[a-z]/.test(watchedPassword) ? "text-green-600" : "text-gray-400"}`}
                        >
                          <Check className="w-3 h-3" />
                          <span>Lowercase letter</span>
                        </div>
                        <div
                          className={`flex items-center space-x-1 ${/[0-9]/.test(watchedPassword) ? "text-green-600" : "text-gray-400"}`}
                        >
                          <Check className="w-3 h-3" />
                          <span>Number</span>
                        </div>
                        <div
                          className={`flex items-center space-x-1 ${/[^A-Za-z0-9]/.test(watchedPassword) ? "text-green-600" : "text-gray-400"}`}
                        >
                          <Check className="w-3 h-3" />
                          <span>Special character</span>
                        </div>
                        <div
                          className={`flex items-center space-x-1 ${watchedPassword.length >= 8 ? "text-green-600" : "text-gray-400"}`}
                        >
                          <Check className="w-3 h-3" />
                          <span>8+ characters</span>
                        </div>
                      </div>
                    </div>
                  )}
                  {errors.password && (
                    <div className="flex items-center space-x-1 text-sm text-red-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.password.message}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password *</Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      {...register("confirmPassword")}
                      className={`${getInputClassName("confirmPassword")} pr-10`}
                      placeholder="Confirm your password"
                      autoComplete="new-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
                    >
                      {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {errors.confirmPassword && (
                    <div className="flex items-center space-x-1 text-sm text-red-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.confirmPassword.message}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Plan Selection */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary-800">Choose Your Plan</h3>
                <Select
                  value={watchedPlan}
                  onValueChange={(value) => setValue("plan", value as "free" | "pro" | "enterprise")}
                >
                  <SelectTrigger className="border-blue-200 focus:border-primary-500">
                    <SelectValue placeholder="Select a plan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="free">
                      <div className="flex items-center justify-between w-full">
                        <span>Free Plan</span>
                        <Badge className="ml-2 bg-gray-100 text-gray-800">$0/month</Badge>
                      </div>
                    </SelectItem>
                    <SelectItem value="pro">
                      <div className="flex items-center justify-between w-full">
                        <span>Pro Plan</span>
                        <Badge className="ml-2 bg-primary-100 text-primary-800">$29/month</Badge>
                      </div>
                    </SelectItem>
                    <SelectItem value="enterprise">
                      <div className="flex items-center justify-between w-full">
                        <span>Enterprise Plan</span>
                        <Badge className="ml-2 bg-secondary-100 text-secondary-800">$99/month</Badge>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Terms and Conditions */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="terms"
                      checked={watchedAgreeToTerms}
                      onCheckedChange={(checked) => setValue("agreeToTerms", checked as boolean)}
                      className="mt-1"
                    />
                    <div className="space-y-1">
                      <Label
                        htmlFor="terms"
                        className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        I agree to the{" "}
                        <Link href="/terms-of-service" className="text-primary-700 hover:underline">
                          Terms of Service
                        </Link>{" "}
                        *
                      </Label>
                    </div>
                  </div>
                  {errors.agreeToTerms && (
                    <div className="flex items-center space-x-1 text-sm text-red-600 ml-6">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.agreeToTerms.message}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="privacy"
                    checked={watchedAgreeToPrivacy}
                    onCheckedChange={(checked) => setValue("agreeToPrivacy", checked as boolean)}
                    className="mt-1"
                  />
                  <Label
                    htmlFor="privacy"
                    className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    I agree to the{" "}
                    <Link href="/privacy-policy" className="text-primary-700 hover:underline">
                      Privacy Policy
                    </Link>
                  </Label>
                </div>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-full bg-primary-700 hover:bg-primary-800 text-white py-3 transition-colors"
                disabled={isLoading || !isValid}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  "Create Account"
                )}
              </Button>

              <div className="text-center text-sm text-gray-600">
                Already have an account?{" "}
                <Link href="/login" className="text-primary-700 hover:underline font-medium">
                  Sign in here
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  )
}
