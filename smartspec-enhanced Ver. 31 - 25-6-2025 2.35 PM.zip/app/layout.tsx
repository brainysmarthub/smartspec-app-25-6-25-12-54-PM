import type React from "react"
import type { Metadata } from "next"
import { ErrorBoundary } from "@/components/error-boundary"
import "./globals.css"

export const metadata: Metadata = {
  title: "SmartSpec - AI-Powered Technical Specifications",
  description:
    "Generate comprehensive technical specifications with AI. Save time, reduce errors, and ensure consistency across all your projects.",
  generator: "SmartSpec",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body>
        <ErrorBoundary>{children}</ErrorBoundary>
      </body>
    </html>
  )
}
