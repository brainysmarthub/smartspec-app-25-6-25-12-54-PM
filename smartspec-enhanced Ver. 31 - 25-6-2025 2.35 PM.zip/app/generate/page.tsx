"use client"

import type React from "react"

import { useState, useRef } from "react"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Upload,
  FileText,
  ImageIcon,
  File,
  X,
  Download,
  Copy,
  Send,
  Loader2,
  Sparkles,
  CheckCircle,
  AlertCircle,
  RefreshCw,
} from "lucide-react"

import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { generateSchema, type GenerateFormData } from "@/lib/validation-schemas"

interface UploadedFile {
  id: string
  name: string
  size: number
  type: string
  content?: string
}

interface GenerationResult {
  id: string
  title: string
  content: string
  format: string
  timestamp: string
  status: "generating" | "completed" | "error"
}

export default function GeneratePage() {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [generationProgress, setGenerationProgress] = useState(0)
  const [results, setResults] = useState<GenerationResult[]>([])
  const [activeTab, setActiveTab] = useState("input")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [error, setError] = useState<string | null>(null)
  const [isFormLoading, setIsFormLoading] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors, isValid, touchedFields },
    setValue,
    watch,
  } = useForm<GenerateFormData>({
    resolver: zodResolver(generateSchema),
    mode: "onChange",
    defaultValues: {
      prompt: "",
      specType: "api",
      company: "",
    },
  })

  const watchedPrompt = watch("prompt")
  const watchedSpecType = watch("specType")

  const specTypes = [
    { value: "api", label: "API Documentation", description: "REST API, GraphQL, OpenAPI specifications" },
    { value: "database", label: "Database Schema", description: "SQL schemas, data models, relationships" },
    { value: "mobile", label: "Mobile App", description: "iOS, Android app requirements" },
    { value: "web", label: "Web Application", description: "Frontend, backend web app specs" },
    { value: "security", label: "Security Protocol", description: "Security requirements, protocols" },
    { value: "system", label: "System Architecture", description: "System design, infrastructure specs" },
    { value: "custom", label: "Custom Specification", description: "Custom technical documentation" },
  ]

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])

    files.forEach((file) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        const newFile: UploadedFile = {
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          size: file.size,
          type: file.type,
          content: e.target?.result as string,
        }
        setUploadedFiles((prev) => [...prev, newFile])
      }
      reader.readAsText(file)
    })
  }

  const removeFile = (fileId: string) => {
    setUploadedFiles((prev) => prev.filter((file) => file.id !== fileId))
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const getFileIcon = (type: string) => {
    if (type.startsWith("image/")) return <ImageIcon className="w-4 h-4" />
    if (type.includes("text") || type.includes("json") || type.includes("xml")) return <FileText className="w-4 h-4" />
    return <File className="w-4 h-4" />
  }

  const onSubmit = async (data: GenerateFormData) => {
    let newResult: GenerationResult

    try {
      setError(null)
      setIsGenerating(true)
      setIsFormLoading(true)
      setGenerationProgress(0)
      setActiveTab("output")

      // Create a new result entry
      newResult = {
        id: Math.random().toString(36).substr(2, 9),
        title: `${specTypes.find((t) => t.value === data.specType)?.label} Specification`,
        content: "",
        format: "markdown",
        timestamp: new Date().toISOString(),
        status: "generating",
      }

      setResults((prev) => [newResult, ...prev])

      // Continue with existing generation logic...
      const progressInterval = setInterval(() => {
        setGenerationProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + Math.random() * 15
        })
      }, 200)

      await new Promise((resolve, reject) => {
        setTimeout(() => {
          if (Math.random() < 0.1) {
            reject(new Error("Failed to generate specification. Please try again."))
          } else {
            resolve(undefined)
          }
        }, 3000)
      })

      clearInterval(progressInterval)
      setGenerationProgress(100)

      const mockContent = generateMockSpecification(data.specType, data.prompt, uploadedFiles)

      setResults((prev) =>
        prev.map((result) =>
          result.id === newResult.id ? { ...result, content: mockContent, status: "completed" } : result,
        ),
      )
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred")
      setResults((prev) => prev.map((result) => (result.id === newResult.id ? { ...result, status: "error" } : result)))
    } finally {
      setIsGenerating(false)
      setIsFormLoading(false)
    }
  }

  const generateMockSpecification = (type: string, userPrompt: string, files: UploadedFile[]) => {
    const baseContent = `# ${specTypes.find((t) => t.value === type)?.label} Specification

## Overview
This specification was generated based on your requirements: "${userPrompt}"

${
  files.length > 0
    ? `## Source Files Analyzed
${files.map((f) => `- ${f.name} (${formatFileSize(f.size)})`).join("\n")}

`
    : ""
}## Requirements

### Functional Requirements
1. **Core Functionality**: The system shall provide the primary features as described in the user prompt
2. **Data Processing**: Handle input data according to specified formats and validation rules
3. **User Interface**: Provide an intuitive interface for user interactions
4. **Integration**: Support integration with external systems and APIs

### Non-Functional Requirements
1. **Performance**: Response time shall not exceed 2 seconds for standard operations
2. **Scalability**: System shall support up to 10,000 concurrent users
3. **Security**: Implement authentication, authorization, and data encryption
4. **Reliability**: System uptime shall be 99.9% or higher

## Technical Specifications

### Architecture Overview
- **Frontend**: React.js with TypeScript
- **Backend**: Node.js with Express.js
- **Database**: PostgreSQL with Redis for caching
- **Authentication**: JWT-based authentication
- **Deployment**: Docker containers on AWS/Azure

### API Endpoints
\`\`\`
GET /api/v1/resources
POST /api/v1/resources
PUT /api/v1/resources/:id
DELETE /api/v1/resources/:id
\`\`\`

### Database Schema
\`\`\`sql
CREATE TABLE resources (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
\`\`\`

## Implementation Guidelines

### Development Standards
- Follow RESTful API design principles
- Implement comprehensive error handling
- Use TypeScript for type safety
- Write unit and integration tests
- Follow security best practices

### Testing Strategy
- Unit tests: 90% code coverage minimum
- Integration tests for all API endpoints
- End-to-end tests for critical user flows
- Performance testing under load

## Deployment & Operations

### Environment Setup
- Development, staging, and production environments
- CI/CD pipeline with automated testing
- Infrastructure as Code (IaC) using Terraform
- Monitoring and logging with ELK stack

### Maintenance
- Regular security updates
- Performance monitoring and optimization
- Backup and disaster recovery procedures
- Documentation updates

---

*Generated on ${new Date().toLocaleDateString()} using SmartSpec AI*`

    return baseContent
  }

  const copyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content)
    // You could add a toast notification here
  }

  const downloadSpecification = (result: GenerationResult) => {
    const blob = new Blob([result.content], { type: "text/markdown" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${result.title.replace(/\s+/g, "_").toLowerCase()}.md`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <AppLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-primary-800 mb-2">AI Specification Generator</h1>
          <p className="text-gray-600">Create comprehensive technical specifications using AI</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 bg-white border border-blue-100">
            <TabsTrigger
              value="input"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Input & Configuration
            </TabsTrigger>
            <TabsTrigger
              value="output"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Generated Specifications
            </TabsTrigger>
          </TabsList>

          {/* Input Tab */}
          <TabsContent value="input" className="space-y-6">
            {error && (
              <Card className="border-red-200 mb-6">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2 text-red-700">
                    <AlertCircle className="w-5 h-5" />
                    <span className="font-medium">Error:</span>
                    <span>{error}</span>
                  </div>
                </CardContent>
              </Card>
            )}
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Main Input Section */}
              <div className="lg:col-span-2 space-y-6">
                {/* Specification Type */}
                <Card className="border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-primary-800 flex items-center">
                      <Sparkles className="w-5 h-5 mr-2" />
                      Specification Type
                    </CardTitle>
                    <CardDescription>Choose the type of specification you want to generate</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Select value={watchedSpecType} onValueChange={(value) => setValue("specType", value as any)}>
                      <SelectTrigger className="border-blue-200 focus:border-primary-500">
                        <SelectValue placeholder="Select specification type" />
                      </SelectTrigger>
                      <SelectContent>
                        {specTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            <div>
                              <div className="font-medium">{type.label}</div>
                              <div className="text-sm text-gray-500">{type.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                {/* Prompt Input */}
                <Card className="border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-primary-800">Describe Your Requirements</CardTitle>
                    <CardDescription>
                      Provide detailed information about what you want to build. Be specific about features,
                      requirements, and constraints.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      {...register("prompt")}
                      placeholder="Example: I need to build a REST API for a task management system..."
                      className={`min-h-[200px] transition-colors ${
                        errors.prompt
                          ? "border-red-500 focus:border-red-500"
                          : touchedFields.prompt && !errors.prompt
                            ? "border-green-500 focus:border-green-500"
                            : "border-blue-200 focus:border-primary-500"
                      }`}
                    />
                    <div className="flex justify-between items-center mt-2">
                      <div className="text-sm text-gray-500">{watchedPrompt?.length || 0}/2000 characters</div>
                      {errors.prompt && (
                        <div className="flex items-center space-x-1 text-sm text-red-600">
                          <AlertCircle className="w-4 h-4" />
                          <span>{errors.prompt.message}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* File Upload */}
                <Card className="border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-primary-800">Upload Supporting Files</CardTitle>
                    <CardDescription>
                      Upload existing documentation, schemas, wireframes, or any relevant files to enhance the
                      specification generation
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div
                        className="border-2 border-dashed border-blue-200 rounded-lg p-8 text-center hover:border-primary-300 transition-colors cursor-pointer"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <Upload className="w-12 h-12 text-primary-600 mx-auto mb-4" />
                        <p className="text-lg font-medium text-primary-800 mb-2">Upload Files</p>
                        <p className="text-gray-600 mb-4">Drag and drop files here, or click to browse</p>
                        <p className="text-sm text-gray-500">Supports: .txt, .md, .json, .xml, .csv, .pdf, images</p>
                        <input
                          ref={fileInputRef}
                          type="file"
                          multiple
                          onChange={handleFileUpload}
                          className="hidden"
                          accept=".txt,.md,.json,.xml,.csv,.pdf,image/*"
                        />
                      </div>

                      {uploadedFiles.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-medium text-primary-800">Uploaded Files</h4>
                          {uploadedFiles.map((file) => (
                            <div key={file.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                              <div className="flex items-center space-x-3">
                                {getFileIcon(file.type)}
                                <div>
                                  <p className="font-medium text-primary-800">{file.name}</p>
                                  <p className="text-sm text-gray-600">{formatFileSize(file.size)}</p>
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeFile(file.id)}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Generation Controls */}
                <Card className="border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-primary-800">Generate Specification</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button
                      onClick={handleSubmit(onSubmit)}
                      disabled={isGenerating || !isValid}
                      className="w-full bg-primary-700 hover:bg-primary-800 text-white transition-colors"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Generate Specification
                        </>
                      )}
                    </Button>

                    {isGenerating && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{Math.round(generationProgress)}%</span>
                        </div>
                        <Progress value={generationProgress} className="h-2" />
                        <p className="text-sm text-gray-600">
                          {generationProgress < 30
                            ? "Analyzing your requirements..."
                            : generationProgress < 60
                              ? "Processing uploaded files..."
                              : generationProgress < 90
                                ? "Generating specification..."
                                : "Finalizing document..."}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Tips */}
                <Card className="border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-primary-800">💡 Tips for Better Results</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Be specific about your requirements and constraints</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Include technical preferences (languages, frameworks)</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Upload existing documentation for context</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Mention scalability and performance requirements</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Usage Stats */}
                <Card className="border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-primary-800">Usage This Month</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Specifications Generated</span>
                        <span>12 / 50</span>
                      </div>
                      <Progress value={24} className="h-2" />
                      <p className="text-sm text-gray-600">38 generations remaining</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Output Tab */}
          <TabsContent value="output" className="space-y-6">
            {results.length === 0 ? (
              <Card className="border-blue-100">
                <CardContent className="p-12 text-center">
                  <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No specifications generated yet</h3>
                  <p className="text-gray-600 mb-4">
                    Go to the Input tab to create your first AI-generated specification
                  </p>
                  <Button
                    onClick={() => setActiveTab("input")}
                    className="bg-primary-700 hover:bg-primary-800 text-white"
                  >
                    Start Generating
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                {results.map((result) => (
                  <Card key={result.id} className="border-blue-100">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-primary-800 flex items-center">
                            {result.status === "generating" && <Loader2 className="w-5 h-5 mr-2 animate-spin" />}
                            {result.status === "completed" && <CheckCircle className="w-5 h-5 mr-2 text-green-600" />}
                            {result.status === "error" && <AlertCircle className="w-5 h-5 mr-2 text-red-600" />}
                            {result.title}
                          </CardTitle>
                          <CardDescription>Generated on {new Date(result.timestamp).toLocaleString()}</CardDescription>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge
                            className={
                              result.status === "completed"
                                ? "bg-green-100 text-green-800"
                                : result.status === "generating"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-red-100 text-red-800"
                            }
                          >
                            {result.status}
                          </Badge>
                          {result.status === "completed" && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => copyToClipboard(result.content)}
                                className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                              >
                                <Copy className="w-4 h-4 mr-2" />
                                Copy
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => downloadSpecification(result)}
                                className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                              >
                                <Download className="w-4 h-4 mr-2" />
                                Download
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {result.status === "generating" ? (
                        <div className="space-y-4">
                          <div className="flex justify-between text-sm">
                            <span>Generating specification...</span>
                            <span>{Math.round(generationProgress)}%</span>
                          </div>
                          <Progress value={generationProgress} className="h-2" />
                        </div>
                      ) : result.status === "completed" ? (
                        <div className="space-y-4">
                          <div className="bg-gray-50 rounded-lg p-4 max-h-96 overflow-y-auto">
                            <pre className="whitespace-pre-wrap text-sm font-mono">{result.content}</pre>
                          </div>
                          <div className="flex items-center justify-between text-sm text-gray-600">
                            <span>{result.content.length} characters</span>
                            <span>Format: {result.format.toUpperCase()}</span>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                          <p className="text-red-600">An error occurred while generating the specification</p>
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-2 bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                          >
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Retry Generation
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  )
}
