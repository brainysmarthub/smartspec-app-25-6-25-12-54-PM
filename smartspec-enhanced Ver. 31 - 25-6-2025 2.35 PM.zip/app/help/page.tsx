"use client"

import { useState } from "react"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import {
  Search,
  MessageCircle,
  Phone,
  Mail,
  Clock,
  Send,
  X,
  HelpCircle,
  User,
  CreditCard,
  Settings,
  Users,
  Shield,
} from "lucide-react"

interface FAQItem {
  id: string
  question: string
  answer: string
  category: string
}

const faqData: FAQItem[] = [
  // Account Setup
  {
    id: "account-1",
    question: "How do I create a SmartSpec account?",
    answer:
      "To create an account, click the 'Sign Up' button on our homepage, enter your email address, create a secure password, and verify your email. You'll be automatically enrolled in our Free plan to get started.",
    category: "Account Setup",
  },
  {
    id: "account-2",
    question: "How do I reset my password?",
    answer:
      "Click 'Forgot Password' on the login page, enter your email address, and we'll send you a secure reset link. Follow the instructions in the email to create a new password.",
    category: "Account Setup",
  },
  {
    id: "account-3",
    question: "Can I change my email address?",
    answer:
      "Yes, you can update your email address in your Profile settings. Go to Settings > Profile and update your email. You'll need to verify the new email address.",
    category: "Account Setup",
  },
  {
    id: "account-4",
    question: "How do I delete my account?",
    answer:
      "To delete your account, go to Settings > Account and click 'Delete Account'. This action is permanent and will remove all your specifications and data.",
    category: "Account Setup",
  },

  // Specification Generation
  {
    id: "spec-1",
    question: "How does AI specification generation work?",
    answer:
      "Our AI analyzes your project description, requirements, and any uploaded files to generate comprehensive technical specifications. It uses industry standards and best practices to ensure accuracy and completeness.",
    category: "Specification Generation",
  },
  {
    id: "spec-2",
    question: "What file formats can I upload?",
    answer:
      "You can upload PDF, DOC, DOCX, TXT, and image files (JPG, PNG, GIF). Our AI can extract relevant information from these files to enhance specification generation.",
    category: "Specification Generation",
  },
  {
    id: "spec-3",
    question: "How accurate are the generated specifications?",
    answer:
      "Our AI achieves 95%+ accuracy for standard specifications. However, we recommend reviewing and customizing the output to match your specific project requirements and local building codes.",
    category: "Specification Generation",
  },
  {
    id: "spec-4",
    question: "Can I edit generated specifications?",
    answer:
      "All generated specifications are fully editable. You can modify text, add sections, remove content, and customize the format to meet your exact needs.",
    category: "Specification Generation",
  },
  {
    id: "spec-5",
    question: "What export formats are available?",
    answer:
      "You can export specifications in PDF, Word (DOCX), plain text (TXT), and HTML formats. Pro and Enterprise users also have access to custom formatting options.",
    category: "Specification Generation",
  },

  // Billing & Plans
  {
    id: "billing-1",
    question: "What's included in the Free plan?",
    answer:
      "The Free plan includes 5 specifications per month, access to basic templates, email support, and standard export formats. Perfect for trying out SmartSpec!",
    category: "Billing & Plans",
  },
  {
    id: "billing-2",
    question: "How do I upgrade my plan?",
    answer:
      "Click 'Upgrade Plan' in the sidebar or go to Settings > Billing. Choose your preferred plan and payment method. Upgrades take effect immediately.",
    category: "Billing & Plans",
  },
  {
    id: "billing-3",
    question: "Can I cancel my subscription anytime?",
    answer:
      "Yes, you can cancel your subscription at any time from Settings > Billing. You'll continue to have access to paid features until the end of your billing period.",
    category: "Billing & Plans",
  },
  {
    id: "billing-4",
    question: "Do you offer refunds?",
    answer:
      "We offer a 30-day money-back guarantee for annual subscriptions. Monthly subscriptions are not eligible for refunds, but you can cancel anytime.",
    category: "Billing & Plans",
  },
  {
    id: "billing-5",
    question: "What payment methods do you accept?",
    answer:
      "We accept all major credit cards (Visa, MasterCard, American Express), PayPal, and bank transfers for Enterprise customers.",
    category: "Billing & Plans",
  },

  // Technical Issues
  {
    id: "tech-1",
    question: "Why is my specification generation taking so long?",
    answer:
      "Generation typically takes 30-60 seconds. Longer times may occur during peak usage or for complex projects with large file uploads. Try refreshing the page if it takes more than 5 minutes.",
    category: "Technical Issues",
  },
  {
    id: "tech-2",
    question: "I'm getting an error when uploading files. What should I do?",
    answer:
      "Ensure your file is under 10MB and in a supported format (PDF, DOC, DOCX, TXT, JPG, PNG, GIF). Clear your browser cache and try again. Contact support if the issue persists.",
    category: "Technical Issues",
  },
  {
    id: "tech-3",
    question: "The website is loading slowly. How can I fix this?",
    answer:
      "Try clearing your browser cache, disabling browser extensions, or switching to a different browser. Check your internet connection and try accessing SmartSpec from a different network if possible.",
    category: "Technical Issues",
  },
  {
    id: "tech-4",
    question: "Can I use SmartSpec on mobile devices?",
    answer:
      "Yes! SmartSpec is fully responsive and works on smartphones and tablets. For the best experience, we recommend using the latest version of Chrome, Safari, or Firefox.",
    category: "Technical Issues",
  },

  // Collaboration
  {
    id: "collab-1",
    question: "How do I invite team members?",
    answer:
      "Go to Settings > Team and click 'Invite Members'. Enter their email addresses and select their role (Viewer, Editor, or Admin). They'll receive an invitation email to join your team.",
    category: "Collaboration",
  },
  {
    id: "collab-2",
    question: "What are the different user roles?",
    answer:
      "Viewers can view specifications, Editors can create and edit specifications, and Admins have full access including team management and billing. Only available on Pro and Enterprise plans.",
    category: "Collaboration",
  },
  {
    id: "collab-3",
    question: "Can multiple people edit a specification simultaneously?",
    answer:
      "Yes! Our real-time collaboration feature allows multiple team members to edit specifications simultaneously. Changes are saved automatically and conflicts are resolved intelligently.",
    category: "Collaboration",
  },

  // Data & Security
  {
    id: "security-1",
    question: "How secure is my data?",
    answer:
      "We use bank-level encryption (AES-256) for data at rest and in transit. All data is stored in SOC 2 compliant data centers with regular security audits and backups.",
    category: "Data & Security",
  },
  {
    id: "security-2",
    question: "Where is my data stored?",
    answer:
      "Data is stored in secure cloud servers in the United States and Europe. Enterprise customers can choose their preferred data location for compliance requirements.",
    category: "Data & Security",
  },
  {
    id: "security-3",
    question: "Do you share my data with third parties?",
    answer:
      "No, we never share your specifications or project data with third parties. We only use aggregated, anonymized data for improving our AI models. See our Privacy Policy for full details.",
    category: "Data & Security",
  },
]

export default function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [chatMessages, setChatMessages] = useState([
    { id: 1, text: "Hi! I'm here to help. What can I assist you with today?", sender: "bot", timestamp: new Date() },
  ])
  const [newMessage, setNewMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)

  const categories = Array.from(new Set(faqData.map((item) => item.category)))

  const filteredFAQs = faqData.filter(
    (item) =>
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Account Setup":
        return <User className="h-5 w-5" />
      case "Specification Generation":
        return <HelpCircle className="h-5 w-5" />
      case "Billing & Plans":
        return <CreditCard className="h-5 w-5" />
      case "Technical Issues":
        return <Settings className="h-5 w-5" />
      case "Collaboration":
        return <Users className="h-5 w-5" />
      case "Data & Security":
        return <Shield className="h-5 w-5" />
      default:
        return <HelpCircle className="h-5 w-5" />
    }
  }

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    const userMessage = {
      id: chatMessages.length + 1,
      text: newMessage,
      sender: "user" as const,
      timestamp: new Date(),
    }

    setChatMessages((prev) => [...prev, userMessage])
    setNewMessage("")
    setIsTyping(true)

    // Simulate bot response
    setTimeout(() => {
      const botResponse = {
        id: chatMessages.length + 2,
        text: "Thanks for your message! I'm connecting you with our support team. In the meantime, you might find our FAQ section helpful, or you can email us at support@smartspec.ai for immediate assistance.",
        sender: "bot" as const,
        timestamp: new Date(),
      }
      setChatMessages((prev) => [...prev, botResponse])
      setIsTyping(false)
    }, 2000)
  }

  return (
    <AppLayout>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Help Center</h1>
              <p className="text-xl text-gray-600 mb-8">
                Find answers to common questions and get the support you need
              </p>

              {/* Search */}
              <div className="max-w-2xl mx-auto relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Search for help topics..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-3 text-lg border-gray-300 focus:border-primary-500 focus:ring-primary-500"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {/* Quick Actions */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Quick Help</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <Card
                    className="hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setIsChatOpen(true)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                          <MessageCircle className="h-5 w-5 text-primary-700" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">Live Chat</CardTitle>
                          <CardDescription>Get instant help from our support team</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>

                  <Card className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center">
                          <Mail className="h-5 w-5 text-secondary-700" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">Email Support</CardTitle>
                          <CardDescription>info@spxid.ai</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                </div>
              </div>

              {/* FAQ Section */}
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>

                {searchQuery && (
                  <div className="mb-4">
                    <p className="text-gray-600">
                      {filteredFAQs.length} result{filteredFAQs.length !== 1 ? "s" : ""} for "{searchQuery}"
                    </p>
                  </div>
                )}

                {categories.map((category) => {
                  const categoryFAQs = filteredFAQs.filter((faq) => faq.category === category)
                  if (categoryFAQs.length === 0) return null

                  return (
                    <div key={category} className="mb-8">
                      <div className="flex items-center space-x-2 mb-4">
                        {getCategoryIcon(category)}
                        <h3 className="text-xl font-semibold text-gray-900">{category}</h3>
                        <Badge variant="secondary">{categoryFAQs.length}</Badge>
                      </div>

                      <Accordion type="single" collapsible className="space-y-2">
                        {categoryFAQs.map((faq) => (
                          <AccordionItem key={faq.id} value={faq.id} className="border rounded-lg px-4">
                            <AccordionTrigger className="text-left hover:no-underline py-4">
                              <span className="font-medium text-gray-900">{faq.question}</span>
                            </AccordionTrigger>
                            <AccordionContent className="pb-4 text-gray-600 leading-relaxed">
                              {faq.answer}
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    </div>
                  )
                })}

                {filteredFAQs.length === 0 && searchQuery && (
                  <div className="text-center py-12">
                    <HelpCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No results found</h3>
                    <p className="text-gray-600 mb-4">We couldn't find any help topics matching "{searchQuery}"</p>
                    <Button onClick={() => setIsChatOpen(true)} className="bg-primary-700 hover:bg-primary-800">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Chat with Support
                    </Button>
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Contact Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Phone className="h-5 w-5" />
                    <span>Contact Support</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600 mb-1">
                      <Mail className="h-4 w-4" />
                      <span>Email</span>
                    </div>
                    <p className="font-medium">info@spxid.ai</p>
                    <p className="text-sm text-gray-500">Response within 24 hours</p>
                  </div>

                  <div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600 mb-1">
                      <Phone className="h-4 w-4" />
                      <span>Phone</span>
                    </div>
                    <p className="font-medium">+1 (965) 6679 3355</p>
                    <p className="text-sm text-gray-500">Business hours only</p>
                  </div>

                  <div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600 mb-1">
                      <Clock className="h-4 w-4" />
                      <span>Support Hours</span>
                    </div>
                    <p className="font-medium">Sunday - Friday</p>
                    <p className="text-sm text-gray-500">9:00 AM - 4:00 PM GMT + 3</p>
                  </div>

                  <Button onClick={() => setIsChatOpen(true)} className="w-full bg-primary-700 hover:bg-primary-800">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Start Live Chat
                  </Button>
                </CardContent>
              </Card>

              {/* Emergency Support */}
              <Card className="border-red-200 bg-red-50">
                <CardHeader>
                  <CardTitle className="text-red-800">Emergency Support</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-red-700 mb-3">For critical issues affecting your business operations:</p>
                  <p className="font-medium text-red-800">hussain@spxid.ai</p>
                  <p className="text-sm text-red-600 mt-1">Available 24/7 for Enterprise customers</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Chat Widget */}
        <div className="fixed bottom-6 right-6 z-50">
          {!isChatOpen && (
            <Button
              onClick={() => setIsChatOpen(true)}
              size="lg"
              className="rounded-full w-14 h-14 bg-primary-700 hover:bg-primary-800 shadow-lg"
            >
              <MessageCircle className="h-6 w-6" />
            </Button>
          )}

          {isChatOpen && (
            <Card className="w-80 h-96 shadow-xl">
              <CardHeader className="bg-primary-700 text-white rounded-t-lg">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">SmartSpec Support</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsChatOpen(false)}
                    className="text-white hover:bg-primary-600 h-8 w-8 p-0"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <CardDescription className="text-blue-100">We're here to help! Ask us anything.</CardDescription>
              </CardHeader>

              <CardContent className="flex flex-col h-64 p-0">
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {chatMessages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                          message.sender === "user" ? "bg-primary-700 text-white" : "bg-gray-100 text-gray-900"
                        }`}
                      >
                        {message.text}
                      </div>
                    </div>
                  ))}

                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 px-3 py-2 rounded-lg text-sm text-gray-600">Typing...</div>
                    </div>
                  )}
                </div>

                <div className="border-t p-3">
                  <div className="flex space-x-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type your message..."
                      onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                      className="flex-1"
                    />
                    <Button onClick={handleSendMessage} size="sm" className="bg-primary-700 hover:bg-primary-800">
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </AppLayout>
  )
}
