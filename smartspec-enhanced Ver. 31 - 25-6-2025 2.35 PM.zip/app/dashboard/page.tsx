"use client"
import Link from "next/link"
import { useState, useEffect } from "react"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ErrorBoundary, ComponentErrorFallback } from "@/components/error-boundary"
import { DashboardCardSkeleton, RecentSpecsSkeleton, QuickActionsSkeleton } from "@/components/loading-skeletons"
import { Plus, FileText, BarChart3, Users, Calendar, TrendingUp, AlertCircle } from "lucide-react"

interface UserData {
  name: string | null
  email: string | null
}

interface DashboardData {
  stats: {
    totalSpecs: number
    thisMonth: number
    creditsUsed: number
    creditsRemaining: number
  }
  recentSpecs: Array<{
    id: number
    title: string
    status: string
    date: string
    type: string
  }>
}

export default function DashboardPage() {
  const [userData, setUserData] = useState<UserData>({
    name: null,
    email: null,
  })
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Simulate data loading with error handling
  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setIsLoading(true)
        setError(null)

        // Simulate API calls with potential for errors
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Simulate occasional network errors (remove in production)
        if (Math.random() < 0.1) {
          throw new Error("Failed to load dashboard data")
        }

        const mockUserData = {
          name: "User",
          email: "user@example.com",
        }

        const mockDashboardData: DashboardData = {
          stats: {
            totalSpecs: 47,
            thisMonth: 12,
            creditsUsed: 1250,
            creditsRemaining: 750,
          },
          recentSpecs: [
            { id: 1, title: "API Documentation Spec", status: "completed", date: "2024-03-15", type: "API" },
            {
              id: 2,
              title: "Database Schema Specification",
              status: "in-progress",
              date: "2024-03-12",
              type: "Database",
            },
            { id: 3, title: "Mobile App Requirements", status: "completed", date: "2024-03-10", type: "Mobile" },
            { id: 4, title: "Security Protocol Spec", status: "draft", date: "2024-03-08", type: "Security" },
          ],
        }

        setUserData(mockUserData)
        setDashboardData(mockDashboardData)
      } catch (err) {
        setError(err instanceof Error ? err.message : "An unexpected error occurred")
      } finally {
        setIsLoading(false)
      }
    }

    loadDashboardData()
  }, [])

  const getGreeting = () => {
    if (userData.name) {
      return `Welcome back, ${userData.name}!`
    }
    return "Welcome back!"
  }

  const retryLoad = () => {
    setError(null)
    setIsLoading(true)
    // Trigger useEffect again
    window.location.reload()
  }

  if (error) {
    return (
      <AppLayout>
        <div className="p-6">
          <Card className="border-red-200">
            <CardContent className="p-8 text-center">
              <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-red-800 mb-2">Failed to Load Dashboard</h2>
              <p className="text-red-600 mb-4">{error}</p>
              <Button onClick={retryLoad} className="bg-primary-700 hover:bg-primary-800 text-white">
                Try Again
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    )
  }

  const usagePercentage = dashboardData
    ? (dashboardData.stats.creditsUsed / (dashboardData.stats.creditsUsed + dashboardData.stats.creditsRemaining)) * 100
    : 0

  return (
    <AppLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary-800 mb-2">Dashboard</h1>
          <p className="text-gray-600">{getGreeting()} Here's what's happening with your specifications today.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {isLoading ? (
            <>
              <DashboardCardSkeleton />
              <DashboardCardSkeleton />
              <DashboardCardSkeleton />
              <DashboardCardSkeleton />
            </>
          ) : dashboardData ? (
            <>
              <ErrorBoundary fallback={ComponentErrorFallback}>
                <Card className="border-blue-100">
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <FileText className="h-8 w-8 text-primary-600" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Total Specifications</p>
                        <p className="text-2xl font-bold text-primary-800">{dashboardData.stats.totalSpecs}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ErrorBoundary>

              <ErrorBoundary fallback={ComponentErrorFallback}>
                <Card className="border-blue-100">
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <Calendar className="h-8 w-8 text-secondary-600" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">This Month</p>
                        <p className="text-2xl font-bold text-primary-800">{dashboardData.stats.thisMonth}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ErrorBoundary>

              <ErrorBoundary fallback={ComponentErrorFallback}>
                <Card className="border-blue-100">
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <BarChart3 className="h-8 w-8 text-accent-600" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Credits Used</p>
                        <p className="text-2xl font-bold text-primary-800">{dashboardData.stats.creditsUsed}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ErrorBoundary>

              <ErrorBoundary fallback={ComponentErrorFallback}>
                <Card className="border-blue-100">
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <TrendingUp className="h-8 w-8 text-green-600" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Credits Left</p>
                        <p className="text-2xl font-bold text-primary-800">{dashboardData.stats.creditsRemaining}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ErrorBoundary>
            </>
          ) : null}
        </div>

        {/* Usage Progress */}
        <ErrorBoundary fallback={ComponentErrorFallback}>
          <Card className="mb-8 border-blue-100">
            <CardHeader>
              <CardTitle className="text-primary-800">Monthly Usage</CardTitle>
              <CardDescription>Your credit usage for this billing period</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <div className="h-4 w-24 bg-gray-200 rounded animate-pulse" />
                    <div className="h-4 w-16 bg-gray-200 rounded animate-pulse" />
                  </div>
                  <div className="h-2 w-full bg-gray-200 rounded animate-pulse" />
                  <div className="h-4 w-48 bg-gray-200 rounded animate-pulse" />
                </div>
              ) : dashboardData ? (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Credits Used</span>
                    <span>
                      {dashboardData.stats.creditsUsed} /{" "}
                      {dashboardData.stats.creditsUsed + dashboardData.stats.creditsRemaining}
                    </span>
                  </div>
                  <Progress value={usagePercentage} className="h-2" />
                  <p className="text-sm text-gray-600">
                    {dashboardData.stats.creditsRemaining} credits remaining this month
                  </p>
                </div>
              ) : null}
            </CardContent>
          </Card>
        </ErrorBoundary>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Specifications */}
          <div className="lg:col-span-2">
            <ErrorBoundary fallback={ComponentErrorFallback}>
              {isLoading ? (
                <RecentSpecsSkeleton />
              ) : dashboardData ? (
                <Card className="border-blue-100">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-primary-800">Recent Specifications</CardTitle>
                        <CardDescription>Your latest specification projects</CardDescription>
                      </div>
                      <Link href="/generate">
                        <Button className="bg-primary-700 hover:bg-primary-800 text-white">
                          <Plus className="w-4 h-4 mr-2" />
                          New Spec
                        </Button>
                      </Link>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {dashboardData.recentSpecs.map((spec) => (
                        <div key={spec.id} className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                          <div className="flex-1">
                            <h3 className="font-medium text-primary-800">{spec.title}</h3>
                            <p className="text-sm text-gray-600">Created on {spec.date}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge
                              className={
                                spec.status === "completed"
                                  ? "bg-green-100 text-green-800"
                                  : spec.status === "in-progress"
                                    ? "bg-blue-100 text-blue-800"
                                    : "bg-gray-100 text-gray-800"
                              }
                            >
                              {spec.status}
                            </Badge>
                            <Badge variant="outline" className="border-primary-200 text-primary-700">
                              {spec.type}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 text-center">
                      <Button
                        variant="outline"
                        className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                      >
                        View All Specifications
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : null}
            </ErrorBoundary>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <ErrorBoundary fallback={ComponentErrorFallback}>
              {isLoading ? (
                <>
                  <QuickActionsSkeleton />
                  <QuickActionsSkeleton />
                </>
              ) : (
                (
                  <>
                  <Card className="border-blue-100">
                    <CardHeader>
                      <CardTitle className="text-primary-800">Quick Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Link href="/generate">
                        <Button className="w-full bg-primary-700 hover:bg-primary-800 text-white justify-start">
                          <Plus className="w-4 h-4 mr-2" />
                          Create New Specification
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        className="w-full bg-white text-primary-700 border-primary-200 hover:bg-primary-50 justify-start"
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        Browse Templates
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full bg-white text-primary-700 border-primary-200 hover:bg-primary-50 justify-start"
                      >
                        <Users className="w-4 h-4 mr-2" />
                        Invite Team Members
                      </Button>
                      <Link href="/profile">
                        <Button
                          variant="outline"
                          className="w-full bg-white text-primary-700 border-primary-200 hover:bg-primary-50 justify-start"\
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>

                  <Card className="border-blue-100">
                    <CardHeader>
                      <CardTitle className="text-primary-800">Recent Activity</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3 text-sm">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-gray-600">API spec completed</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          <span className="text-gray-600">Database spec in progress</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                          <span className="text-gray-600">Mobile spec draft saved</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-primary-500 rounded-full"></div>
                          <span className="text-gray-600">Team member invited</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
                )
              )}
            </ErrorBoundary>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
