"use client"

import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  Target,
  Award,
  MapPin,
  Mail,
  Phone,
  Calendar,
  Building,
  Zap,
  Shield,
  Brain,
  FileText,
  CheckCircle,
  ArrowRight,
  Linkedin,
  Twitter,
  Globe,
} from "lucide-react"

export default function AboutPage() {
  const teamMembers = [
    {
      name: "Sarah Chen",
      role: "CEO & Co-Founder",
      bio: "Former architect at Gensler with 12+ years in commercial design. Led specification teams for Fortune 500 headquarters and major healthcare facilities.",
      education: "M.Arch from MIT, B.S. Architecture from UC Berkeley",
      expertise: ["Architecture", "Specifications", "Team Leadership"],
      avatar: "SC",
      linkedin: "#",
      twitter: "#",
    },
    {
      name: "Dr. Michael Rodriguez",
      role: "CTO & Co-Founder",
      bio: "AI researcher and former Google engineer. PhD in Machine Learning with focus on natural language processing and document understanding.",
      education: "PhD Computer Science from Stanford, MS from Carnegie Mellon",
      expertise: ["AI/ML", "NLP", "System Architecture"],
      avatar: "MR",
      linkedin: "#",
      twitter: "#",
    },
    {
      name: "Emily Watson",
      role: "Head of Product",
      bio: "Product leader with 8+ years at Autodesk and Bentley Systems. Expert in design software and workflow optimization for AEC industry.",
      education: "MBA from Wharton, B.S. Industrial Design from RISD",
      expertise: ["Product Strategy", "UX Design", "AEC Software"],
      avatar: "EW",
      linkedin: "#",
      twitter: "#",
    },
    {
      name: "David Kim",
      role: "VP of Engineering",
      bio: "Full-stack engineer and former tech lead at Dropbox. Specializes in scalable systems and developer tools for enterprise applications.",
      education: "M.S. Computer Science from Stanford, B.S. from KAIST",
      expertise: ["Backend Systems", "DevOps", "Enterprise Software"],
      avatar: "DK",
      linkedin: "#",
      twitter: "#",
    },
  ]

  const timeline = [
    {
      year: "2021",
      title: "Company Founded",
      description: "Sarah and Michael start SmartSpec to solve specification challenges in architecture",
      milestone: "MVP Development",
    },
    {
      year: "2022",
      title: "Product Launch",
      description: "First AI-powered specification generator goes live with 10 beta customers",
      milestone: "Beta Launch",
    },
    {
      year: "2022",
      title: "Seed Funding",
      description: "$2M seed round led by Bessemer Venture Partners",
      milestone: "$2M Raised",
    },
    {
      year: "2023",
      title: "Enterprise Launch",
      description: "Launch enterprise features and onboard first Fortune 500 customers",
      milestone: "Enterprise Ready",
    },
    {
      year: "2023",
      title: "Industry Partnerships",
      description: "Strategic partnerships with Herman Miller, Steelcase, and major design firms",
      milestone: "Key Partnerships",
    },
    {
      year: "2024",
      title: "Series A",
      description: "$15M Series A funding to accelerate growth and expand team",
      milestone: "$15M Series A",
    },
    {
      year: "2024",
      title: "AI Platform 2.0",
      description: "Launch next-generation AI platform with RAG architecture",
      milestone: "Platform 2.0",
    },
  ]

  const partners = [
    { name: "Herman Miller", type: "Manufacturing Partner", logo: "HM" },
    { name: "Steelcase", type: "Technology Partner", logo: "SC" },
    { name: "Knoll", type: "Data Partner", logo: "KN" },
    { name: "Gensler", type: "Design Partner", logo: "GE" },
    { name: "HOK", type: "Innovation Partner", logo: "HO" },
    { name: "IDEO", type: "Design Partner", logo: "ID" },
  ]

  const values = [
    {
      icon: Zap,
      title: "Innovation",
      description: "Pushing the boundaries of what's possible in specification technology",
    },
    {
      icon: Target,
      title: "Accuracy",
      description: "Delivering 95%+ precision in every specification we generate",
    },
    {
      icon: CheckCircle,
      title: "Efficiency",
      description: "Reducing hours of manual work to minutes with intelligent automation",
    },
    {
      icon: Award,
      title: "Industry Expertise",
      description: "Built by architects and designers who understand real-world challenges",
    },
  ]

  const technologies = [
    {
      icon: Brain,
      title: "AI-Powered Generation",
      description:
        "Custom language models trained specifically on furniture specifications and CSI MasterFormat standards",
    },
    {
      icon: FileText,
      title: "RAG Architecture",
      description:
        "Retrieval-Augmented Generation ensures accuracy by referencing manufacturer catalogs and industry standards",
    },
    {
      icon: Shield,
      title: "Document Processing",
      description: "Intelligent parsing of manufacturer catalogs, CAD files, and specification documents",
    },
    {
      icon: CheckCircle,
      title: "CSI Integration",
      description: "Native compliance with Construction Specifications Institute MasterFormat standards",
    },
  ]

  return (
    <AppLayout>
      <div className="min-h-screen">
        {/* Hero Section */}
        <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary-50 to-blue-50">
          <div className="max-w-6xl mx-auto text-center">
            <Badge className="mb-4 bg-primary-100 text-primary-800 hover:bg-primary-200">About SmartSpec</Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Revolutionizing Furniture
              <span className="text-primary-700 block">Specification with AI</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-4xl mx-auto">
              We're transforming how architects and designers create technical specifications, making the process
              faster, more accurate, and infinitely more efficient through AI-powered CSI MasterFormat generation.
            </p>

            {/* Key Metrics */}
            <div className="grid md:grid-cols-3 gap-8 mt-12">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary-700">50+</div>
                <div className="text-gray-600">Architecture Firms</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary-700">10,000+</div>
                <div className="text-gray-600">Specifications Generated</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary-700">95%</div>
                <div className="text-gray-600">Accuracy Rate</div>
              </div>
            </div>
          </div>
        </section>

        {/* Our Story */}
        <section className="py-24 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
                <div className="space-y-4 text-lg text-gray-600">
                  <p>
                    SmartSpec was born from frustration. As practicing architects, our founders Sarah Chen and Dr.
                    Michael Rodriguez witnessed firsthand the countless hours wasted on manual specification writing—a
                    process that was both tedious and error-prone.
                  </p>
                  <p>
                    Sarah, having led specification teams at Gensler for major commercial projects, knew there had to be
                    a better way. Michael, with his AI research background at Google, saw the potential for machine
                    learning to transform this critical but overlooked aspect of design.
                  </p>
                  <p>
                    Together, they founded SmartSpec in 2021 with a simple mission: use artificial intelligence to make
                    specification writing as effortless as it should be, while maintaining the accuracy and compliance
                    that the industry demands.
                  </p>
                </div>
              </div>
              <div className="bg-blue-50 p-8 rounded-2xl">
                <h3 className="text-xl font-semibold text-primary-800 mb-4">The Challenge We Solve</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                    <span className="text-gray-700">Architects spend 15-20% of project time on specifications</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                    <span className="text-gray-700">Manual processes lead to inconsistencies and errors</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                    <span className="text-gray-700">Keeping up with manufacturer updates is nearly impossible</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                    <span className="text-gray-700">CSI MasterFormat compliance requires deep expertise</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Meet Our Team</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Industry veterans and technology experts working together to transform specification workflows
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {teamMembers.map((member, index) => (
                <Card key={index} className="border-blue-100 hover:border-primary-200 transition-colors">
                  <CardContent className="p-6 text-center">
                    <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-xl font-bold text-primary-700">{member.avatar}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-primary-800 mb-1">{member.name}</h3>
                    <p className="text-primary-600 font-medium mb-3">{member.role}</p>
                    <p className="text-sm text-gray-600 mb-4">{member.bio}</p>

                    <div className="space-y-2 mb-4">
                      <p className="text-xs text-gray-500 font-medium">Education</p>
                      <p className="text-xs text-gray-600">{member.education}</p>
                    </div>

                    <div className="flex flex-wrap gap-1 mb-4">
                      {member.expertise.map((skill, skillIndex) => (
                        <Badge key={skillIndex} className="bg-blue-100 text-blue-800 text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex justify-center gap-2">
                      <Button variant="outline" size="sm" className="p-2">
                        <Linkedin className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="p-2">
                        <Twitter className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Technology Section */}
        <section className="py-24 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Technology</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Cutting-edge AI and machine learning technologies purpose-built for the architecture industry
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {technologies.map((tech, index) => (
                <Card key={index} className="border-blue-100">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <tech.icon className="w-6 h-6 text-primary-700" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-primary-800 mb-2">{tech.title}</h3>
                        <p className="text-gray-600">{tech.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* How It Works */}
            <Card className="border-blue-100 bg-blue-50">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-primary-800 mb-6 text-center">How SmartSpec Works</h3>
                <div className="grid md:grid-cols-3 gap-8">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                      1
                    </div>
                    <h4 className="font-semibold text-primary-800 mb-2">Input Requirements</h4>
                    <p className="text-sm text-gray-600">
                      Describe your furniture needs in natural language or upload existing specifications
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                      2
                    </div>
                    <h4 className="font-semibold text-primary-800 mb-2">AI Processing</h4>
                    <p className="text-sm text-gray-600">
                      Our AI analyzes requirements against manufacturer catalogs and CSI standards
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                      3
                    </div>
                    <h4 className="font-semibold text-primary-800 mb-2">Generate Specifications</h4>
                    <p className="text-sm text-gray-600">
                      Receive complete, accurate specifications in CSI MasterFormat ready for your project
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                The principles that guide everything we do at SmartSpec
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <Card key={index} className="border-blue-100 text-center">
                  <CardContent className="p-6">
                    <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <value.icon className="w-8 h-8 text-primary-700" />
                    </div>
                    <h3 className="text-lg font-semibold text-primary-800 mb-2">{value.title}</h3>
                    <p className="text-gray-600">{value.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Timeline Section */}
        <section className="py-24 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Journey</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Key milestones in SmartSpec's growth and evolution
              </p>
            </div>

            <div className="space-y-8">
              {timeline.map((event, index) => (
                <div key={index} className={`flex items-center gap-8 ${index % 2 === 1 ? "flex-row-reverse" : ""}`}>
                  <div className="flex-1">
                    <Card className="border-blue-100">
                      <CardContent className="p-6">
                        <div className="flex items-center gap-3 mb-3">
                          <Badge className="bg-primary-600 text-white">{event.year}</Badge>
                          <Badge className="bg-green-100 text-green-800">{event.milestone}</Badge>
                        </div>
                        <h3 className="text-lg font-semibold text-primary-800 mb-2">{event.title}</h3>
                        <p className="text-gray-600">{event.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="w-4 h-4 bg-primary-600 rounded-full flex-shrink-0"></div>
                  <div className="flex-1"></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Partners Section */}
        <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Industry Partnerships</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Collaborating with leading manufacturers and design firms to advance the industry
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {partners.map((partner, index) => (
                <Card key={index} className="border-blue-100">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-primary-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-lg font-bold text-primary-700">{partner.logo}</span>
                    </div>
                    <h3 className="font-semibold text-primary-800 mb-1">{partner.name}</h3>
                    <p className="text-sm text-gray-600">{partner.type}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Certifications */}
            <div className="mt-16 text-center">
              <h3 className="text-2xl font-bold text-primary-800 mb-8">Certifications & Memberships</h3>
              <div className="flex justify-center gap-8 flex-wrap">
                <div className="flex items-center gap-3">
                  <Shield className="w-8 h-8 text-green-600" />
                  <div className="text-left">
                    <p className="font-semibold text-gray-900">SOC 2 Type II</p>
                    <p className="text-sm text-gray-600">Security Certified</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Award className="w-8 h-8 text-blue-600" />
                  <div className="text-left">
                    <p className="font-semibold text-gray-900">ISO 27001</p>
                    <p className="text-sm text-gray-600">Information Security</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Building className="w-8 h-8 text-primary-600" />
                  <div className="text-left">
                    <p className="font-semibold text-gray-900">CSI Member</p>
                    <p className="text-sm text-gray-600">Construction Specifications Institute</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="w-8 h-8 text-secondary-600" />
                  <div className="text-left">
                    <p className="font-semibold text-gray-900">AIA Partner</p>
                    <p className="text-sm text-gray-600">American Institute of Architects</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-24 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Get in Touch</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Ready to transform your specification workflow? We'd love to hear from you.
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-bold text-primary-800 mb-6">Contact Information</h3>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-6 h-6 text-primary-600 mt-1" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Headquarters</h4>
                      <p className="text-gray-600">
                        123 Innovation Drive
                        <br />
                        San Francisco, CA 94105
                        <br />
                        United States
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Mail className="w-6 h-6 text-primary-600 mt-1" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Email</h4>
                      <p className="text-gray-600">
                        General: hello@smartspec.ai
                        <br />
                        Support: support@smartspec.ai
                        <br />
                        Sales: sales@smartspec.ai
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Phone className="w-6 h-6 text-primary-600 mt-1" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Phone</h4>
                      <p className="text-gray-600">
                        Sales: +1 (555) 123-4567
                        <br />
                        Support: +1 (555) 123-4568
                        <br />
                        Hours: Mon-Fri 9AM-6PM PST
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <Card className="border-blue-100">
                  <CardContent className="p-8">
                    <h3 className="text-xl font-bold text-primary-800 mb-6">Ready to Get Started?</h3>
                    <div className="space-y-4">
                      <Button className="w-full bg-primary-700 hover:bg-primary-800 text-white">
                        <Calendar className="w-4 h-4 mr-2" />
                        Schedule a Demo
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                      >
                        <ArrowRight className="w-4 h-4 mr-2" />
                        Start Free Trial
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        Download Resources
                      </Button>
                    </div>

                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <p className="text-sm text-gray-600 mb-3">Follow us for updates:</p>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="p-2">
                          <Linkedin className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" className="p-2">
                          <Twitter className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" className="p-2">
                          <Globe className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </div>
    </AppLayout>
  )
}
