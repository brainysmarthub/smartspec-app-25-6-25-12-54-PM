"use client"

import { useState } from "react"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, X, Star, CreditCard, Users, Zap, Shield, FileText, Clock, Award, TrendingUp } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart,
} from "recharts"

interface PlanFeature {
  name: string
  free: boolean | string
  pro: boolean | string
  enterprise: boolean | string
}

interface Testimonial {
  name: string
  role: string
  company: string
  content: string
  rating: number
}

export default function BillingPage() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly")
  const [currentPlan, setCurrentPlan] = useState<"free" | "pro" | "enterprise">("pro")
  const [selectedPlan, setSelectedPlan] = useState<"free" | "pro" | "enterprise">("pro")
  const [isUpgrading, setIsUpgrading] = useState(false)
  const [showDetailedUsage, setShowDetailedUsage] = useState(false)
  const [subscriptionStatus, setSubscriptionStatus] = useState<"active" | "cancelled" | "past_due">("active")
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [showPauseModal, setShowPauseModal] = useState(false)
  const [showChangePlanModal, setShowChangePlanModal] = useState(false)
  const [showRetentionOffer, setShowRetentionOffer] = useState(false)
  const [selectedNewPlan, setSelectedNewPlan] = useState<"free" | "pro" | "enterprise">("pro")
  const [isPaused, setIsPaused] = useState(false)
  const [pauseEndDate, setPauseEndDate] = useState<string>("")

  const plans = {
    free: {
      name: "Free",
      price: { monthly: 0, yearly: 0 },
      description: "Perfect for getting started",
      color: "bg-gray-100 text-gray-800",
      borderColor: "border-gray-200",
      popular: false,
    },
    pro: {
      name: "Pro",
      price: { monthly: 29, yearly: 290 }, // 2 months free
      description: "For growing teams and projects",
      color: "bg-primary-100 text-primary-800",
      borderColor: "border-primary-300",
      popular: true,
    },
    enterprise: {
      name: "Enterprise",
      price: { monthly: 99, yearly: 990 }, // 2 months free
      description: "For large organizations",
      color: "bg-secondary-100 text-secondary-800",
      borderColor: "border-secondary-300",
      popular: false,
    },
  }

  const features: PlanFeature[] = [
    {
      name: "Specifications per month",
      free: "5",
      pro: "Unlimited",
      enterprise: "Unlimited",
    },
    {
      name: "AI-powered generation",
      free: true,
      pro: true,
      enterprise: true,
    },
    {
      name: "Basic templates",
      free: true,
      pro: true,
      enterprise: true,
    },
    {
      name: "Premium templates",
      free: false,
      pro: true,
      enterprise: true,
    },
    {
      name: "Custom templates",
      free: false,
      pro: false,
      enterprise: true,
    },
    {
      name: "Team collaboration",
      free: false,
      pro: "Up to 10 members",
      enterprise: "Unlimited members",
    },
    {
      name: "Version control",
      free: false,
      pro: true,
      enterprise: true,
    },
    {
      name: "Export formats",
      free: "PDF, Markdown",
      pro: "PDF, Markdown, Word, HTML",
      enterprise: "All formats + Custom",
    },
    {
      name: "API access",
      free: false,
      pro: "1,000 calls/month",
      enterprise: "Unlimited",
    },
    {
      name: "Storage",
      free: "100MB",
      pro: "10GB",
      enterprise: "Unlimited",
    },
    {
      name: "Priority support",
      free: false,
      pro: true,
      enterprise: true,
    },
    {
      name: "Phone support",
      free: false,
      pro: false,
      enterprise: true,
    },
    {
      name: "Dedicated account manager",
      free: false,
      pro: false,
      enterprise: true,
    },
    {
      name: "Custom integrations",
      free: false,
      pro: false,
      enterprise: true,
    },
    {
      name: "Advanced security (SSO)",
      free: false,
      pro: false,
      enterprise: true,
    },
    {
      name: "Compliance (SOC2, HIPAA)",
      free: false,
      pro: false,
      enterprise: true,
    },
  ]

  const testimonials: Testimonial[] = [
    {
      name: "Sarah Chen",
      role: "Lead Developer",
      company: "TechFlow Inc.",
      content:
        "SmartSpec Pro has transformed how we create technical documentation. The AI suggestions are incredibly accurate and save us hours every week.",
      rating: 5,
    },
    {
      name: "Michael Rodriguez",
      role: "Engineering Manager",
      company: "DataCore Systems",
      content:
        "The team collaboration features in Pro are game-changing. Our entire engineering team can now work on specifications simultaneously.",
      rating: 5,
    },
    {
      name: "Emily Watson",
      role: "CTO",
      company: "InnovateLabs",
      content:
        "Enterprise plan's custom integrations allowed us to seamlessly connect SmartSpec with our existing workflow. ROI was immediate.",
      rating: 5,
    },
  ]

  const currentUsage = {
    specsGenerated: 47,
    storageUsed: 2.3, // GB
    apiCalls: 750,
    teamMembers: 3,
  }

  const detailedUsageData = {
    apiCalls: {
      thisMonth: 750,
      limit: currentPlan === "free" ? 0 : currentPlan === "pro" ? 1000 : 999999,
      dailyUsage: [
        { date: "Dec 1", calls: 45 },
        { date: "Dec 2", calls: 52 },
        { date: "Dec 3", calls: 38 },
        { date: "Dec 4", calls: 61 },
        { date: "Dec 5", calls: 43 },
        { date: "Dec 6", calls: 55 },
        { date: "Dec 7", calls: 48 },
        { date: "Dec 8", calls: 67 },
        { date: "Dec 9", calls: 41 },
        { date: "Dec 10", calls: 59 },
        { date: "Dec 11", calls: 44 },
        { date: "Dec 12", calls: 52 },
        { date: "Dec 13", calls: 38 },
        { date: "Dec 14", calls: 47 },
      ],
    },
    storage: {
      used: 2.3,
      limit: currentPlan === "free" ? 0.1 : currentPlan === "pro" ? 10 : 999999,
      breakdown: [
        { category: "Documents", size: 1.2, color: "#3B82F6" },
        { category: "Templates", size: 0.6, color: "#10B981" },
        { category: "Generated Files", size: 0.3, color: "#F59E0B" },
        { category: "Cache", size: 0.2, color: "#EF4444" },
      ],
    },
    processingTime: {
      thisMonth: 145, // minutes
      limit: currentPlan === "free" ? 60 : currentPlan === "pro" ? 500 : 999999,
      dailyUsage: [
        { date: "Dec 1", minutes: 12 },
        { date: "Dec 2", minutes: 15 },
        { date: "Dec 3", minutes: 8 },
        { date: "Dec 4", minutes: 18 },
        { date: "Dec 5", minutes: 11 },
        { date: "Dec 6", minutes: 14 },
        { date: "Dec 7", minutes: 9 },
        { date: "Dec 8", minutes: 16 },
        { date: "Dec 9", minutes: 7 },
        { date: "Dec 10", minutes: 13 },
        { date: "Dec 11", minutes: 10 },
        { date: "Dec 12", minutes: 12 },
      ],
    },
    featureUsage: [
      { feature: "Specification Generation", usage: 45, color: "#3B82F6" },
      { feature: "Document Processing", usage: 28, color: "#10B981" },
      { feature: "AI Queries", usage: 18, color: "#F59E0B" },
      { feature: "Template Creation", usage: 9, color: "#EF4444" },
    ],
    historicalTrends: {
      months: ["Oct 2024", "Nov 2024", "Dec 2024"],
      apiCalls: [620, 680, 750],
      storage: [1.8, 2.1, 2.3],
      processingTime: [98, 125, 145],
      specifications: [32, 41, 47],
    },
  }

  const subscriptionData = {
    status: subscriptionStatus,
    nextBillingDate: "January 1, 2025",
    nextBillingAmount: billingCycle === "yearly" ? plans[currentPlan].price.yearly : plans[currentPlan].price.monthly,
    subscriptionId: "sub_1234567890",
    startDate: "October 1, 2024",
    isPaused: isPaused,
    pauseEndDate: pauseEndDate,
    history: [
      {
        date: "December 1, 2024",
        action: "Plan Renewed",
        details: `${plans[currentPlan].name} ${billingCycle} plan`,
        amount: `$${billingCycle === "yearly" ? plans[currentPlan].price.yearly : plans[currentPlan].price.monthly}`,
      },
      {
        date: "November 15, 2024",
        action: "Billing Cycle Changed",
        details: `Changed from monthly to ${billingCycle}`,
        amount: "No charge",
      },
      {
        date: "October 1, 2024",
        action: "Subscription Started",
        details: `Upgraded to ${plans[currentPlan].name} plan`,
        amount: `$${plans[currentPlan].price.monthly}`,
      },
    ],
    retentionOffers: [
      {
        title: "50% Off Next 3 Months",
        description: "Continue with Pro at half price",
        discount: "50%",
        duration: "3 months",
        savings: "$43.50",
      },
      {
        title: "Free Month Extension",
        description: "Get an extra month free",
        discount: "100%",
        duration: "1 month",
        savings: "$29.00",
      },
    ],
  }

  const getYearlySavings = (monthlyPrice: number) => {
    const yearlyPrice = monthlyPrice * 10 // 2 months free
    const monthlyCost = monthlyPrice * 12
    return monthlyCost - yearlyPrice
  }

  const handleUpgrade = async (plan: "free" | "pro" | "enterprise") => {
    setIsUpgrading(true)
    setSelectedPlan(plan)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setCurrentPlan(plan)
    setIsUpgrading(false)
  }

  const handleCancelSubscription = async (acceptOffer?: boolean, offerIndex?: number) => {
    if (acceptOffer && offerIndex !== undefined) {
      // Apply retention offer
      setShowRetentionOffer(false)
      setShowCancelModal(false)
      // Simulate applying offer
      await new Promise((resolve) => setTimeout(resolve, 1000))
      return
    }

    if (!showRetentionOffer) {
      setShowRetentionOffer(true)
      return
    }

    // Proceed with cancellation
    setSubscriptionStatus("cancelled")
    setShowCancelModal(false)
    setShowRetentionOffer(false)
  }

  const handlePauseSubscription = async (endDate: string) => {
    setIsPaused(true)
    setPauseEndDate(endDate)
    setShowPauseModal(false)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
  }

  const handleReactivateSubscription = async () => {
    setSubscriptionStatus("active")
    setIsPaused(false)
    setPauseEndDate("")
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
  }

  const handleChangePlan = async (newPlan: "free" | "pro" | "enterprise") => {
    const oldPlan = currentPlan
    const oldPrice = plans[oldPlan].price[billingCycle]
    const newPrice = plans[newPlan].price[billingCycle]

    // Calculate prorated amount
    const daysInMonth = 30
    const daysRemaining = 15 // Simulate 15 days remaining
    const proratedCredit = (oldPrice / daysInMonth) * daysRemaining
    const proratedCharge = (newPrice / daysInMonth) * daysRemaining
    const netAmount = proratedCharge - proratedCredit

    setCurrentPlan(newPlan)
    setShowChangePlanModal(false)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
  }

  const calculateProration = (fromPlan: keyof typeof plans, toPlan: keyof typeof plans) => {
    const fromPrice = plans[fromPlan].price[billingCycle]
    const toPrice = plans[toPlan].price[billingCycle]
    const daysRemaining = 15 // Simulate 15 days remaining in billing cycle
    const daysInCycle = billingCycle === "monthly" ? 30 : 365

    const proratedCredit = (fromPrice / daysInCycle) * daysRemaining
    const proratedCharge = (toPrice / daysInCycle) * daysRemaining
    const netAmount = proratedCharge - proratedCredit

    return {
      credit: proratedCredit,
      charge: proratedCharge,
      net: netAmount,
      daysRemaining,
    }
  }

  const renderFeatureValue = (value: boolean | string) => {
    if (typeof value === "boolean") {
      return value ? <CheckCircle className="w-5 h-5 text-green-600" /> : <X className="w-5 h-5 text-gray-400" />
    }
    return <span className="text-sm font-medium">{value}</span>
  }

  return (
    <AppLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary-800 mb-2">Billing & Plans</h1>
          <p className="text-gray-600">Choose the perfect plan for your needs and upgrade anytime</p>
        </div>

        <Tabs defaultValue="plans" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-white border border-blue-100">
            <TabsTrigger
              value="plans"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Plans & Pricing
            </TabsTrigger>
            <TabsTrigger
              value="usage"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Current Usage
            </TabsTrigger>
            <TabsTrigger
              value="billing"
              className="data-[state=active]:bg-primary-100 data-[state=active]:text-primary-800"
            >
              Billing History
            </TabsTrigger>
          </TabsList>

          {/* Plans & Pricing Tab */}
          <TabsContent value="plans" className="space-y-8">
            {/* Current Plan Status */}
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Current Plan</CardTitle>
                <CardDescription>You are currently on the {plans[currentPlan].name} plan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
                      <Award className="w-6 h-6 text-primary-700" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-primary-800">{plans[currentPlan].name} Plan</h3>
                      <p className="text-gray-600">{plans[currentPlan].description}</p>
                    </div>
                  </div>
                  <Badge className={plans[currentPlan].color}>Active</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Subscription Management */}
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800 flex items-center justify-between">
                  Subscription Management
                  <Badge
                    className={
                      subscriptionStatus === "active"
                        ? "bg-green-100 text-green-800"
                        : subscriptionStatus === "cancelled"
                          ? "bg-red-100 text-red-800"
                          : "bg-yellow-100 text-yellow-800"
                    }
                  >
                    {subscriptionStatus === "active"
                      ? "Active"
                      : subscriptionStatus === "cancelled"
                        ? "Cancelled"
                        : "Past Due"}
                  </Badge>
                </CardTitle>
                <CardDescription>Manage your subscription settings and billing</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Subscription Status */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-primary-800 mb-2">Current Subscription</h4>
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">Plan</span>
                          <span className="font-semibold text-primary-800">{plans[currentPlan].name}</span>
                        </div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">Billing Cycle</span>
                          <span className="font-semibold text-primary-800 capitalize">{billingCycle}</span>
                        </div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">Status</span>
                          <Badge
                            className={
                              subscriptionStatus === "active"
                                ? "bg-green-100 text-green-800"
                                : subscriptionStatus === "cancelled"
                                  ? "bg-red-100 text-red-800"
                                  : "bg-yellow-100 text-yellow-800"
                            }
                          >
                            {subscriptionStatus === "active"
                              ? "Active"
                              : subscriptionStatus === "cancelled"
                                ? "Cancelled"
                                : "Past Due"}
                          </Badge>
                        </div>
                        {isPaused && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Paused Until</span>
                            <span className="font-semibold text-orange-800">{pauseEndDate}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-primary-800 mb-2">Next Billing</h4>
                      <div className="bg-green-50 p-4 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">Date</span>
                          <span className="font-semibold text-primary-800">{subscriptionData.nextBillingDate}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Amount</span>
                          <span className="font-semibold text-primary-800">${subscriptionData.nextBillingAmount}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-primary-800">Subscription Actions</h4>

                    {subscriptionStatus === "active" && !isPaused && (
                      <>
                        <Button
                          onClick={() => setShowChangePlanModal(true)}
                          className="w-full bg-primary-700 hover:bg-primary-800 text-white"
                        >
                          Change Plan
                        </Button>

                        <Button
                          onClick={() => setShowPauseModal(true)}
                          variant="outline"
                          className="w-full bg-white text-orange-700 border-orange-200 hover:bg-orange-50"
                        >
                          Pause Subscription
                        </Button>

                        <Button
                          onClick={() => setShowCancelModal(true)}
                          variant="outline"
                          className="w-full bg-white text-red-700 border-red-200 hover:bg-red-50"
                        >
                          Cancel Subscription
                        </Button>
                      </>
                    )}

                    {subscriptionStatus === "cancelled" && (
                      <Button
                        onClick={handleReactivateSubscription}
                        className="w-full bg-green-700 hover:bg-green-800 text-white"
                      >
                        Reactivate Subscription
                      </Button>
                    )}

                    {isPaused && (
                      <Button
                        onClick={handleReactivateSubscription}
                        className="w-full bg-blue-700 hover:bg-blue-800 text-white"
                      >
                        Resume Subscription
                      </Button>
                    )}

                    {subscriptionStatus === "past_due" && (
                      <>
                        <Button className="w-full bg-red-700 hover:bg-red-800 text-white">Update Payment Method</Button>
                        <Button
                          onClick={handleReactivateSubscription}
                          variant="outline"
                          className="w-full bg-white text-green-700 border-green-200 hover:bg-green-50"
                        >
                          Retry Payment
                        </Button>
                      </>
                    )}
                  </div>
                </div>

                {/* Subscription History */}
                <div>
                  <h4 className="font-semibold text-primary-800 mb-4">Subscription History</h4>
                  <div className="space-y-3">
                    {subscriptionData.history.map((event, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center">
                            <Clock className="w-4 h-4 text-primary-700" />
                          </div>
                          <div>
                            <p className="font-medium text-primary-800">{event.action}</p>
                            <p className="text-sm text-gray-600">{event.details}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600">{event.date}</p>
                          <p className="font-semibold text-primary-800">{event.amount}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Billing Cycle Toggle */}
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Billing Cycle</CardTitle>
                <CardDescription>Save up to 17% with yearly billing</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center gap-4">
                  <span className={billingCycle === "monthly" ? "font-semibold text-primary-800" : "text-gray-600"}>
                    Monthly
                  </span>
                  <Switch
                    checked={billingCycle === "yearly"}
                    onCheckedChange={(checked) => setBillingCycle(checked ? "yearly" : "monthly")}
                  />
                  <span className={billingCycle === "yearly" ? "font-semibold text-primary-800" : "text-gray-600"}>
                    Yearly
                  </span>
                  {billingCycle === "yearly" && <Badge className="bg-green-100 text-green-800 ml-2">Save 17%</Badge>}
                </div>
              </CardContent>
            </Card>

            {/* Pricing Cards */}
            <div className="grid lg:grid-cols-3 gap-8">
              {Object.entries(plans).map(([key, plan]) => {
                const planKey = key as keyof typeof plans
                const isCurrentPlan = currentPlan === planKey
                const price = plan.price[billingCycle]
                const monthlyPrice = billingCycle === "yearly" ? price / 12 : price

                return (
                  <Card
                    key={key}
                    className={`relative ${plan.borderColor} ${plan.popular ? "ring-2 ring-primary-200" : ""} ${isCurrentPlan ? "bg-blue-50" : ""}`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-primary-600 text-white px-4 py-1">Most Popular</Badge>
                      </div>
                    )}
                    {isCurrentPlan && (
                      <div className="absolute -top-3 right-4">
                        <Badge className="bg-green-600 text-white px-3 py-1">Current Plan</Badge>
                      </div>
                    )}

                    <CardHeader className="text-center pb-4">
                      <CardTitle className="text-primary-800 text-xl">{plan.name}</CardTitle>
                      <div className="py-4">
                        <div className="text-4xl font-bold text-primary-700">
                          ${Math.round(monthlyPrice)}
                          <span className="text-lg font-normal text-gray-600">/month</span>
                        </div>
                        {billingCycle === "yearly" && price > 0 && (
                          <div className="text-sm text-green-600 mt-1">
                            Save ${getYearlySavings(plan.price.monthly)}/year
                          </div>
                        )}
                      </div>
                      <CardDescription className="text-center">{plan.description}</CardDescription>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      {/* Key Features for this plan */}
                      <div className="space-y-3">
                        {planKey === "free" && (
                          <>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">5 specifications/month</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Basic templates</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Email support</span>
                            </div>
                          </>
                        )}

                        {planKey === "pro" && (
                          <>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Unlimited specifications</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Premium templates</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Team collaboration (10 members)</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Priority support</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">API access (1K calls/month)</span>
                            </div>
                          </>
                        )}

                        {planKey === "enterprise" && (
                          <>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Everything in Pro</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Unlimited team members</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Custom integrations</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Dedicated account manager</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <span className="text-sm">Advanced security & compliance</span>
                            </div>
                          </>
                        )}
                      </div>

                      <Button
                        className={`w-full ${
                          isCurrentPlan
                            ? "bg-gray-100 text-gray-600 cursor-not-allowed"
                            : planKey === "pro"
                              ? "bg-primary-700 hover:bg-primary-800 text-white"
                              : "bg-white text-primary-700 border border-primary-200 hover:bg-primary-50"
                        }`}
                        onClick={() => !isCurrentPlan && handleUpgrade(planKey)}
                        disabled={isCurrentPlan || isUpgrading}
                      >
                        {isCurrentPlan
                          ? "Current Plan"
                          : isUpgrading && selectedPlan === planKey
                            ? "Upgrading..."
                            : planKey === "free"
                              ? "Downgrade to Free"
                              : planKey === "enterprise"
                                ? "Contact Sales"
                                : "Upgrade to Pro"}
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Feature Comparison Table */}
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Detailed Feature Comparison</CardTitle>
                <CardDescription>Compare all features across our plans</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 font-semibold text-primary-800">Features</th>
                        <th className="text-center py-3 px-4 font-semibold text-primary-800">Free</th>
                        <th className="text-center py-3 px-4 font-semibold text-primary-800">
                          Pro
                          <Badge className="ml-2 bg-primary-100 text-primary-800 text-xs">Popular</Badge>
                        </th>
                        <th className="text-center py-3 px-4 font-semibold text-primary-800">Enterprise</th>
                      </tr>
                    </thead>
                    <tbody>
                      {features.map((feature, index) => (
                        <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium text-gray-900">{feature.name}</td>
                          <td className="py-3 px-4 text-center">{renderFeatureValue(feature.free)}</td>
                          <td className="py-3 px-4 text-center">{renderFeatureValue(feature.pro)}</td>
                          <td className="py-3 px-4 text-center">{renderFeatureValue(feature.enterprise)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Testimonials */}
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">What Our Customers Say</CardTitle>
                <CardDescription>See how SmartSpec is helping teams worldwide</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  {testimonials.map((testimonial, index) => (
                    <div key={index} className="bg-blue-50 p-6 rounded-lg">
                      <div className="flex items-center gap-1 mb-3">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-gray-700 mb-4 italic">"{testimonial.content}"</p>
                      <div>
                        <p className="font-semibold text-primary-800">{testimonial.name}</p>
                        <p className="text-sm text-gray-600">
                          {testimonial.role} at {testimonial.company}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Current Usage Tab */}
          <TabsContent value="usage" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <FileText className="w-8 h-8 text-primary-600" />
                    <Badge className="bg-blue-100 text-blue-800">This Month</Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-2xl font-bold text-primary-800">{currentUsage.specsGenerated}</p>
                    <p className="text-sm text-gray-600">Specifications Generated</p>
                    {currentPlan === "free" && (
                      <div className="mt-2">
                        <Progress value={(currentUsage.specsGenerated / 5) * 100} className="h-2" />
                        <p className="text-xs text-gray-500 mt-1">{5 - currentUsage.specsGenerated} remaining</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <Zap className="w-8 h-8 text-secondary-600" />
                    <Badge className="bg-green-100 text-green-800">API Calls</Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-2xl font-bold text-primary-800">{currentUsage.apiCalls}</p>
                    <p className="text-sm text-gray-600">API Calls Used</p>
                    {currentPlan === "pro" && (
                      <div className="mt-2">
                        <Progress value={(currentUsage.apiCalls / 1000) * 100} className="h-2" />
                        <p className="text-xs text-gray-500 mt-1">{1000 - currentUsage.apiCalls} remaining</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <Shield className="w-8 h-8 text-accent-600" />
                    <Badge className="bg-purple-100 text-purple-800">Storage</Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-2xl font-bold text-primary-800">{currentUsage.storageUsed}GB</p>
                    <p className="text-sm text-gray-600">Storage Used</p>
                    {currentPlan !== "enterprise" && (
                      <div className="mt-2">
                        <Progress
                          value={
                            currentPlan === "free"
                              ? (currentUsage.storageUsed / 0.1) * 100
                              : (currentUsage.storageUsed / 10) * 100
                          }
                          className="h-2"
                        />
                        <p className="text-xs text-gray-500 mt-1">
                          {currentPlan === "free"
                            ? (0.1 - currentUsage.storageUsed).toFixed(1)
                            : (10 - currentUsage.storageUsed).toFixed(1)}
                          GB remaining
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <Users className="w-8 h-8 text-green-600" />
                    <Badge className="bg-orange-100 text-orange-800">Team</Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-2xl font-bold text-primary-800">{currentUsage.teamMembers}</p>
                    <p className="text-sm text-gray-600">Team Members</p>
                    {currentPlan === "pro" && (
                      <div className="mt-2">
                        <Progress value={(currentUsage.teamMembers / 10) * 100} className="h-2" />
                        <p className="text-xs text-gray-500 mt-1">{10 - currentUsage.teamMembers} slots remaining</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Add this after the usage cards grid */}
            <div className="flex justify-center">
              <Button
                onClick={() => setShowDetailedUsage(true)}
                className="bg-primary-700 hover:bg-primary-800 text-white px-6 py-2"
              >
                View Detailed Usage
              </Button>
            </div>

            {/* Detailed Usage Modal/Overlay */}
            {showDetailedUsage && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div className="bg-white rounded-lg max-w-7xl w-full max-h-[90vh] overflow-y-auto">
                  <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-primary-800">Detailed Usage Analytics</h2>
                    <Button
                      variant="outline"
                      onClick={() => setShowDetailedUsage(false)}
                      className="text-gray-600 hover:text-gray-800"
                    >
                      ✕ Close
                    </Button>
                  </div>

                  <div className="p-6 space-y-8">
                    {/* API Usage Section */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xl font-semibold text-primary-800 flex items-center">
                          <Zap className="w-5 h-5 mr-2" />
                          API Calls Usage
                        </h3>
                        <Badge className="bg-blue-100 text-blue-800">
                          {detailedUsageData.apiCalls.thisMonth} /{" "}
                          {detailedUsageData.apiCalls.limit === 999999 ? "∞" : detailedUsageData.apiCalls.limit} calls
                        </Badge>
                      </div>

                      <div className="grid lg:grid-cols-3 gap-6">
                        <Card className="lg:col-span-2">
                          <CardHeader>
                            <CardTitle className="text-lg">Daily API Usage (Last 14 Days)</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                              <BarChart data={detailedUsageData.apiCalls.dailyUsage}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="date" />
                                <YAxis />
                                <Tooltip />
                                <Bar dataKey="calls" fill="#3B82F6" />
                              </BarChart>
                            </ResponsiveContainer>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Usage Summary</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div>
                              <div className="flex justify-between text-sm mb-1">
                                <span>This Month</span>
                                <span className="font-semibold">{detailedUsageData.apiCalls.thisMonth}</span>
                              </div>
                              <Progress
                                value={
                                  detailedUsageData.apiCalls.limit === 999999
                                    ? 25
                                    : (detailedUsageData.apiCalls.thisMonth / detailedUsageData.apiCalls.limit) * 100
                                }
                                className="h-2"
                              />
                            </div>
                            <div className="text-sm text-gray-600">
                              <p>Average per day: {Math.round(detailedUsageData.apiCalls.thisMonth / 14)}</p>
                              <p>Peak day: 67 calls</p>
                              <p>
                                Remaining:{" "}
                                {detailedUsageData.apiCalls.limit === 999999
                                  ? "∞"
                                  : detailedUsageData.apiCalls.limit - detailedUsageData.apiCalls.thisMonth}
                              </p>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>

                    {/* Storage Usage Section */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xl font-semibold text-primary-800 flex items-center">
                          <Shield className="w-5 h-5 mr-2" />
                          Storage Usage
                        </h3>
                        <Badge className="bg-purple-100 text-purple-800">
                          {detailedUsageData.storage.used}GB /{" "}
                          {detailedUsageData.storage.limit === 999999 ? "∞" : detailedUsageData.storage.limit}GB
                        </Badge>
                      </div>

                      <div className="grid lg:grid-cols-3 gap-6">
                        <Card className="lg:col-span-2">
                          <CardHeader>
                            <CardTitle className="text-lg">Storage Breakdown</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                              <PieChart>
                                <Pie
                                  data={detailedUsageData.storage.breakdown}
                                  cx="50%"
                                  cy="50%"
                                  outerRadius={100}
                                  fill="#8884d8"
                                  dataKey="size"
                                  label={({ category, size }) => `${category}: ${size}GB`}
                                >
                                  {detailedUsageData.storage.breakdown.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                  ))}
                                </Pie>
                                <Tooltip />
                              </PieChart>
                            </ResponsiveContainer>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Storage Details</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            {detailedUsageData.storage.breakdown.map((item, index) => (
                              <div key={index} className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                                  <span className="text-sm">{item.category}</span>
                                </div>
                                <span className="text-sm font-semibold">{item.size}GB</span>
                              </div>
                            ))}
                            <div className="pt-2 border-t">
                              <Progress
                                value={
                                  detailedUsageData.storage.limit === 999999
                                    ? 23
                                    : (detailedUsageData.storage.used / detailedUsageData.storage.limit) * 100
                                }
                                className="h-2"
                              />
                              <p className="text-xs text-gray-500 mt-1">
                                {detailedUsageData.storage.limit === 999999
                                  ? "Unlimited"
                                  : `${(detailedUsageData.storage.limit - detailedUsageData.storage.used).toFixed(1)}GB remaining`}
                              </p>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>

                    {/* Processing Time Section */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xl font-semibold text-primary-800 flex items-center">
                          <Clock className="w-5 h-5 mr-2" />
                          Processing Time
                        </h3>
                        <Badge className="bg-green-100 text-green-800">
                          {Math.floor(detailedUsageData.processingTime.thisMonth / 60)}h{" "}
                          {detailedUsageData.processingTime.thisMonth % 60}m used
                        </Badge>
                      </div>

                      <div className="grid lg:grid-cols-3 gap-6">
                        <Card className="lg:col-span-2">
                          <CardHeader>
                            <CardTitle className="text-lg">Daily Processing Time</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                              <AreaChart data={detailedUsageData.processingTime.dailyUsage}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="date" />
                                <YAxis />
                                <Tooltip />
                                <Area
                                  type="monotone"
                                  dataKey="minutes"
                                  stroke="#10B981"
                                  fill="#10B981"
                                  fillOpacity={0.3}
                                />
                              </AreaChart>
                            </ResponsiveContainer>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Time Summary</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div>
                              <div className="flex justify-between text-sm mb-1">
                                <span>This Month</span>
                                <span className="font-semibold">{detailedUsageData.processingTime.thisMonth}min</span>
                              </div>
                              <Progress
                                value={
                                  detailedUsageData.processingTime.limit === 999999
                                    ? 29
                                    : (detailedUsageData.processingTime.thisMonth /
                                        detailedUsageData.processingTime.limit) *
                                      100
                                }
                                className="h-2"
                              />
                            </div>
                            <div className="text-sm text-gray-600">
                              <p>Average per day: {Math.round(detailedUsageData.processingTime.thisMonth / 12)}min</p>
                              <p>Peak day: 18 minutes</p>
                              <p>Efficiency: 94% (Good)</p>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>

                    {/* Feature Usage Section */}
                    <div className="space-y-4">
                      <h3 className="text-xl font-semibold text-primary-800 flex items-center">
                        <FileText className="w-5 h-5 mr-2" />
                        Usage by Feature
                      </h3>

                      <div className="grid lg:grid-cols-2 gap-6">
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Feature Distribution</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                              <PieChart>
                                <Pie
                                  data={detailedUsageData.featureUsage}
                                  cx="50%"
                                  cy="50%"
                                  outerRadius={100}
                                  fill="#8884d8"
                                  dataKey="usage"
                                  label={({ feature, usage }) => `${feature}: ${usage}%`}
                                >
                                  {detailedUsageData.featureUsage.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                  ))}
                                </Pie>
                                <Tooltip />
                              </PieChart>
                            </ResponsiveContainer>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Feature Breakdown</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            {detailedUsageData.featureUsage.map((feature, index) => (
                              <div key={index} className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <div
                                      className="w-3 h-3 rounded-full"
                                      style={{ backgroundColor: feature.color }}
                                    ></div>
                                    <span className="text-sm font-medium">{feature.feature}</span>
                                  </div>
                                  <span className="text-sm font-semibold">{feature.usage}%</span>
                                </div>
                                <Progress value={feature.usage} className="h-2" />
                              </div>
                            ))}
                          </CardContent>
                        </Card>
                      </div>
                    </div>

                    {/* Historical Trends Section */}
                    <div className="space-y-4">
                      <h3 className="text-xl font-semibold text-primary-800 flex items-center">
                        <TrendingUp className="w-5 h-5 mr-2" />
                        Historical Trends (Last 3 Months)
                      </h3>

                      <div className="grid lg:grid-cols-2 gap-6">
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">API Calls & Processing Time</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                              <LineChart
                                data={detailedUsageData.historicalTrends.months.map((month, index) => ({
                                  month,
                                  apiCalls: detailedUsageData.historicalTrends.apiCalls[index],
                                  processingTime: detailedUsageData.historicalTrends.processingTime[index],
                                }))}
                              >
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Line type="monotone" dataKey="apiCalls" stroke="#3B82F6" strokeWidth={2} />
                                <Line type="monotone" dataKey="processingTime" stroke="#10B981" strokeWidth={2} />
                              </LineChart>
                            </ResponsiveContainer>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Storage & Specifications</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                              <LineChart
                                data={detailedUsageData.historicalTrends.months.map((month, index) => ({
                                  month,
                                  storage: detailedUsageData.historicalTrends.storage[index],
                                  specifications: detailedUsageData.historicalTrends.specifications[index],
                                }))}
                              >
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Line type="monotone" dataKey="storage" stroke="#F59E0B" strokeWidth={2} />
                                <Line type="monotone" dataKey="specifications" stroke="#EF4444" strokeWidth={2} />
                              </LineChart>
                            </ResponsiveContainer>
                          </CardContent>
                        </Card>
                      </div>
                    </div>

                    {/* Usage Insights */}
                    <Card className="border-blue-100">
                      <CardHeader>
                        <CardTitle className="text-primary-800">Usage Insights & Recommendations</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                            <div className="flex items-start gap-3">
                              <TrendingUp className="w-5 h-5 text-green-600 mt-0.5" />
                              <div>
                                <h4 className="font-semibold text-green-800">Growing Usage</h4>
                                <p className="text-sm text-green-700 mt-1">
                                  Your usage has increased 21% over the last 3 months, indicating growing productivity
                                  with SmartSpec.
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                            <div className="flex items-start gap-3">
                              <Zap className="w-5 h-5 text-blue-600 mt-0.5" />
                              <div>
                                <h4 className="font-semibold text-blue-800">Efficient Usage</h4>
                                <p className="text-sm text-blue-700 mt-1">
                                  You're using features efficiently with 94% processing success rate and optimal
                                  resource allocation.
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>

                        {currentPlan === "pro" && detailedUsageData.apiCalls.thisMonth > 800 && (
                          <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                            <div className="flex items-start gap-3">
                              <Clock className="w-5 h-5 text-yellow-600 mt-0.5" />
                              <div>
                                <h4 className="font-semibold text-yellow-800">Consider Enterprise</h4>
                                <p className="text-sm text-yellow-700 mt-1">
                                  You're approaching your API limit. Enterprise plan offers unlimited API calls and
                                  additional features.
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Billing History Tab */}
          <TabsContent value="billing" className="space-y-6">
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Billing History</CardTitle>
                <CardDescription>View your past invoices and payment history</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { date: "Dec 1, 2024", amount: "$29.00", status: "Paid", plan: "Pro Monthly" },
                    { date: "Nov 1, 2024", amount: "$29.00", status: "Paid", plan: "Pro Monthly" },
                    { date: "Oct 1, 2024", amount: "$29.00", status: "Paid", plan: "Pro Monthly" },
                    { date: "Sep 1, 2024", amount: "$0.00", status: "Free", plan: "Free Plan" },
                  ].map((invoice, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                          <CreditCard className="w-5 h-5 text-primary-700" />
                        </div>
                        <div>
                          <p className="font-medium text-primary-800">{invoice.plan}</p>
                          <p className="text-sm text-gray-600">{invoice.date}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-semibold text-primary-800">{invoice.amount}</span>
                        <Badge
                          className={
                            invoice.status === "Paid" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                          }
                        >
                          {invoice.status}
                        </Badge>
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                        >
                          Download
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Payment Method */}
            <Card className="border-blue-100">
              <CardHeader>
                <CardTitle className="text-primary-800">Payment Method</CardTitle>
                <CardDescription>Manage your payment information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                      <CreditCard className="w-5 h-5 text-primary-700" />
                    </div>
                    <div>
                      <p className="font-medium text-primary-800">•••• •••• •••• 4242</p>
                      <p className="text-sm text-gray-600">Expires 12/2027</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    className="bg-white text-primary-700 border-primary-200 hover:bg-primary-50"
                  >
                    Update Card
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Change Plan Modal */}
      {showChangePlanModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-primary-800">Change Subscription Plan</h2>
              <p className="text-gray-600 mt-1">Select your new plan and see prorated billing details</p>
            </div>

            <div className="p-6 space-y-6">
              {/* Plan Selection */}
              <div className="space-y-4">
                <h3 className="font-semibold text-primary-800">Select New Plan</h3>
                <div className="grid gap-4">
                  {Object.entries(plans).map(([key, plan]) => {
                    const planKey = key as keyof typeof plans
                    const isSelected = selectedNewPlan === planKey
                    const isCurrent = currentPlan === planKey

                    return (
                      <div
                        key={key}
                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                          isSelected ? "border-primary-300 bg-primary-50" : "border-gray-200 hover:border-gray-300"
                        } ${isCurrent ? "opacity-50 cursor-not-allowed" : ""}`}
                        onClick={() => !isCurrent && setSelectedNewPlan(planKey)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-4 h-4 rounded-full border-2 ${
                                isSelected ? "border-primary-600 bg-primary-600" : "border-gray-300"
                              }`}
                            >
                              {isSelected && <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>}
                            </div>
                            <div>
                              <h4 className="font-semibold text-primary-800">
                                {plan.name}
                                {isCurrent && <Badge className="ml-2 bg-gray-100 text-gray-600">Current</Badge>}
                              </h4>
                              <p className="text-sm text-gray-600">{plan.description}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-primary-800">
                              ${billingCycle === "yearly" ? Math.round(plan.price.yearly / 12) : plan.price.monthly}
                              /month
                            </p>
                            {billingCycle === "yearly" && <p className="text-sm text-green-600">Billed yearly</p>}
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Prorated Billing Calculation */}
              {selectedNewPlan !== currentPlan && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-primary-800 mb-3">Prorated Billing Details</h3>
                  {(() => {
                    const proration = calculateProration(currentPlan, selectedNewPlan)
                    return (
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>
                            Credit for remaining {proration.daysRemaining} days of {plans[currentPlan].name}:
                          </span>
                          <span className="text-green-600">-${proration.credit.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>
                            Charge for {proration.daysRemaining} days of {plans[selectedNewPlan].name}:
                          </span>
                          <span className="text-primary-800">+${proration.charge.toFixed(2)}</span>
                        </div>
                        <div className="border-t pt-2 flex justify-between font-semibold">
                          <span>Net amount {proration.net >= 0 ? "due today" : "credited"}:</span>
                          <span className={proration.net >= 0 ? "text-primary-800" : "text-green-600"}>
                            {proration.net >= 0 ? "+" : ""}${proration.net.toFixed(2)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mt-2">
                          Your next full billing cycle will begin on {subscriptionData.nextBillingDate}
                        </p>
                      </div>
                    )
                  })()}
                </div>
              )}
            </div>

            <div className="p-6 border-t border-gray-200 flex gap-3">
              <Button variant="outline" onClick={() => setShowChangePlanModal(false)} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={() => handleChangePlan(selectedNewPlan)}
                disabled={selectedNewPlan === currentPlan}
                className="flex-1 bg-primary-700 hover:bg-primary-800 text-white"
              >
                Confirm Plan Change
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Subscription Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-red-800">Cancel Subscription</h2>
              <p className="text-gray-600 mt-1">We're sorry to see you go. Here are some options to consider.</p>
            </div>

            <div className="p-6 space-y-6">
              {!showRetentionOffer ? (
                <>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-red-800 mb-2">What happens when you cancel:</h3>
                    <ul className="text-sm text-red-700 space-y-1">
                      <li>• Your subscription will remain active until {subscriptionData.nextBillingDate}</li>
                      <li>• You'll lose access to Pro features after the current billing period</li>
                      <li>• Your data will be preserved for 30 days in case you want to reactivate</li>
                      <li>• No refunds will be issued for the current billing period</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-primary-800 mb-3">Before you go, consider these alternatives:</h3>
                    <div className="grid gap-3">
                      <div className="p-3 border border-blue-200 rounded-lg">
                        <h4 className="font-medium text-blue-800">Pause your subscription instead</h4>
                        <p className="text-sm text-blue-600">
                          Take a break for up to 3 months without losing your data
                        </p>
                      </div>
                      <div className="p-3 border border-green-200 rounded-lg">
                        <h4 className="font-medium text-green-800">Downgrade to Free plan</h4>
                        <p className="text-sm text-green-600">Keep basic features and your data safe</p>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-xl font-semibold text-primary-800 mb-2">
                      Wait! We have special offers for you
                    </h3>
                    <p className="text-gray-600">Choose one of these exclusive deals to continue with SmartSpec</p>
                  </div>

                  <div className="grid gap-4">
                    {subscriptionData.retentionOffers.map((offer, index) => (
                      <div key={index} className="p-4 border border-green-200 rounded-lg bg-green-50">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-green-800">{offer.title}</h4>
                          <Badge className="bg-green-600 text-white">{offer.discount} OFF</Badge>
                        </div>
                        <p className="text-sm text-green-700 mb-3">{offer.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-green-600">
                            Save {offer.savings} over {offer.duration}
                          </span>
                          <Button
                            onClick={() => handleCancelSubscription(true, index)}
                            className="bg-green-700 hover:bg-green-800 text-white"
                            size="sm"
                          >
                            Accept Offer
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="p-6 border-t border-gray-200 flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowCancelModal(false)
                  setShowRetentionOffer(false)
                }}
                className="flex-1"
              >
                Keep Subscription
              </Button>
              <Button
                onClick={() => handleCancelSubscription()}
                className="flex-1 bg-red-700 hover:bg-red-800 text-white"
              >
                {showRetentionOffer ? "Cancel Anyway" : "Continue Cancellation"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Pause Subscription Modal */}
      {showPauseModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-lg w-full">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-primary-800">Pause Subscription</h2>
              <p className="text-gray-600 mt-1">Temporarily pause your subscription for up to 3 months</p>
            </div>

            <div className="p-6 space-y-4">
              <div className="bg-orange-50 p-4 rounded-lg">
                <h3 className="font-semibold text-orange-800 mb-2">What happens when you pause:</h3>
                <ul className="text-sm text-orange-700 space-y-1">
                  <li>• Billing will be suspended during the pause period</li>
                  <li>• You'll retain access to your current features</li>
                  <li>• Your data and settings will be preserved</li>
                  <li>• Subscription will automatically resume on the selected date</li>
                </ul>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Resume subscription on:</label>
                <input
                  type="date"
                  min={new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]}
                  max={new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  onChange={(e) => setPauseEndDate(e.target.value)}
                />
                <p className="text-xs text-gray-500 mt-1">Minimum 1 week, maximum 3 months</p>
              </div>
            </div>

            <div className="p-6 border-t border-gray-200 flex gap-3">
              <Button variant="outline" onClick={() => setShowPauseModal(false)} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={() => handlePauseSubscription(pauseEndDate)}
                disabled={!pauseEndDate}
                className="flex-1 bg-orange-700 hover:bg-orange-800 text-white"
              >
                Pause Subscription
              </Button>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  )
}
