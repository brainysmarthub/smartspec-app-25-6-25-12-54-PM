"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Home,
  User,
  BarChart3,
  Settings,
  LogIn,
  UserPlus,
  Sparkles,
  Menu,
  X,
  CreditCard,
  HelpCircle,
  Bell,
  Building2,
  BookOpen,
} from "lucide-react"

interface SidebarNavProps {
  className?: string
}

export function SidebarNav({ className }: SidebarNavProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)
  const pathname = usePathname()
  const router = useRouter()

  const navigationItems = [
    {
      title: "Main",
      items: [
        { name: "Home", href: "/", icon: Home },
        { name: "About", href: "/about", icon: Building2 },
        { name: "Dashboard", href: "/dashboard", icon: BarChart3 },
        { name: "Generate", href: "/generate", icon: Sparkles, badge: "AI" },
        { name: "Resources", href: "/resources", icon: BookOpen, badge: "New" },
      ],
    },
    {
      title: "Account",
      items: [
        { name: "Profile", href: "/profile", icon: User },
        { name: "Settings", href: "/settings", icon: Settings },
        { name: "Billing", href: "/billing", icon: CreditCard },
      ],
    },
    {
      title: "Auth",
      items: [
        { name: "Login", href: "/login", icon: LogIn },
        { name: "Sign Up", href: "/signup", icon: UserPlus },
      ],
    },
    {
      title: "Support",
      items: [
        { name: "Help Center", href: "/help", icon: HelpCircle },
        { name: "Notifications", href: "/notifications", icon: Bell },
      ],
    },
  ]

  const isActive = (href: string) => {
    if (href === "/") {
      return pathname === "/"
    }
    return pathname.startsWith(href)
  }

  const handleUpgradeClick = () => {
    // Navigate to home page with pricing scroll parameter
    router.push("/?scrollTo=pricing")
  }

  return (
    <>
      {/* Mobile Menu Button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="bg-white/80 backdrop-blur-md border-blue-200"
        >
          {isCollapsed ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </Button>
      </div>

      {/* Sidebar */}
      <div
        className={`fixed left-0 top-0 h-full bg-white/95 backdrop-blur-md border-r border-blue-100 z-40 transition-transform duration-300 ${
          isCollapsed ? "-translate-x-full lg:translate-x-0" : "translate-x-0"
        } ${isCollapsed ? "lg:w-16" : "w-64"} ${className}`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b border-blue-100">
            <div className="flex items-center justify-between">
              {!isCollapsed && (
                <Link href="/" className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-primary-700 rounded-lg flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-xl font-bold text-primary-800">SmartSpec</span>
                </Link>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsCollapsed(!isCollapsed)}
                className="hidden lg:flex text-gray-500 hover:text-primary-700"
              >
                {isCollapsed ? <Menu className="w-4 h-4" /> : <X className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {navigationItems.map((section) => (
              <div key={section.title}>
                {!isCollapsed && (
                  <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">{section.title}</h3>
                )}
                <div className="space-y-1">
                  {section.items.map((item) => {
                    const Icon = item.icon
                    const active = isActive(item.href)
                    return (
                      <Link key={item.name} href={item.href} className="block">
                        <Button
                          variant={active ? "default" : "ghost"}
                          className={`w-full justify-start ${
                            active
                              ? "bg-primary-100 text-primary-800 hover:bg-primary-200"
                              : "text-gray-700 hover:text-primary-700 hover:bg-blue-50"
                          } ${isCollapsed ? "px-2" : "px-3"}`}
                        >
                          <Icon className={`w-4 h-4 ${isCollapsed ? "" : "mr-3"}`} />
                          {!isCollapsed && (
                            <>
                              <span className="flex-1 text-left">{item.name}</span>
                              {item.badge && (
                                <Badge className="ml-2 bg-primary-600 text-white text-xs">{item.badge}</Badge>
                              )}
                            </>
                          )}
                        </Button>
                      </Link>
                    )
                  })}
                </div>
                {!isCollapsed && <Separator className="mt-4" />}
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-blue-100">
            {!isCollapsed ? (
              <div className="space-y-3">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-primary-800">Pro Plan</span>
                    <Badge className="bg-primary-100 text-primary-800 text-xs">Active</Badge>
                  </div>
                  <div className="text-xs text-gray-600">12/50 specs used</div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                    <div className="bg-primary-600 h-1.5 rounded-full" style={{ width: "24%" }}></div>
                  </div>
                </div>
                <Button
                  onClick={handleUpgradeClick}
                  variant="outline"
                  size="sm"
                  className="w-full bg-white text-primary-700 border-primary-200 hover:bg-primary-50 transition-all duration-200 hover:shadow-sm"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Upgrade Plan
                </Button>
              </div>
            ) : (
              <div className="flex justify-center">
                <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-primary-700" />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Overlay */}
      {!isCollapsed && (
        <div className="lg:hidden fixed inset-0 bg-black/20 z-30" onClick={() => setIsCollapsed(true)} />
      )}
    </>
  )
}
