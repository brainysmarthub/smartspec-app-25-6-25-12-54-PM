"use client"

import type React from "react"

import { SidebarNav } from "./sidebar-nav"

interface AppLayoutProps {
  children: React.ReactNode
}

export function AppLayout({ children }: AppLayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <SidebarNav />
      <div className="lg:ml-64 transition-all duration-300">{children}</div>
    </div>
  )
}
